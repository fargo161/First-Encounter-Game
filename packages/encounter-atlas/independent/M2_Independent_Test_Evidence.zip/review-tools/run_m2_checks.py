import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent
WORK = ROOT / 'work/m2-independent-review'
CHECKPOINT = WORK / 'checkpoint'
EVIDENCE = WORK / 'evidence'
commands = []

def run(label, argv, cwd=CHECKPOINT, env_extra=None):
    env = dict(os.environ); env.update(env_extra or {})
    argv = [str(a) for a in argv]
    p = subprocess.run(argv, cwd=cwd, env=env, capture_output=True, text=True, encoding='utf-8', errors='replace')
    (EVIDENCE / (label + '.txt')).write_text(f'CWD: {cwd}\nENV: {json.dumps(env_extra or {})}\nCOMMAND: {subprocess.list2cmdline(argv)}\nEXIT: {p.returncode}\n\nSTDOUT:\n{p.stdout}\nSTDERR:\n{p.stderr}', encoding='utf-8')
    counts = {k: int(v) for k,v in re.findall(r'^# (tests|pass|fail|skipped|cancelled|todo) (\d+)$', p.stdout, re.M)}
    commands.append({'label': label, 'cwd': str(cwd), 'argv': argv, 'env': env_extra or {}, 'exit': p.returncode, 'counts': counts})
    (EVIDENCE / 'commands.json').write_text(json.dumps(commands, indent=2), encoding='utf-8')
    print(f'{label}: exit {p.returncode}, {counts}', flush=True)
    assert p.returncode == 0, label
    return p

node = shutil.which('node')
run('node-version', [node, '--version'])
run('npm-version', [shutil.which('npm.cmd'), '--version'])
run('python-version', [sys.executable, '--version'])
run('m0-baseline-audit', [node, 'scripts/audit-baseline.cjs'])
tests = sorted((CHECKPOINT / 'tests').glob('*.test.mjs'))
run('builder-m1-m2-tests', [node, '--test', '--test-reporter=tap', *tests])
run('unchanged-independent-m1-tests', [node, '--test', '--test-reporter=tap', ROOT / 'outputs/M1_Independent_Contract_Tests.test.mjs'], env_extra={'ENCOUNTER_CHECKPOINT': str(CHECKPOINT)})
run('builder-manifest-verifier', [sys.executable, 'scripts/verify-checkpoint.py', Path(r'C:\Users\mcdon\Downloads\Encounter_M2_Tester_Handoff\Encounter_M2_Checkpoint.identity.json')])

paths = [CHECKPOINT / 'package.json']
for folder in ['src','tests','scripts','content']:
    paths.extend(p for p in (CHECKPOINT / folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
entries = [{'path': p.relative_to(CHECKPOINT).as_posix(), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(paths)]
digest = hashlib.sha256(json.dumps(entries, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
stored = json.loads((CHECKPOINT / 'evidence/M2_source_identity.json').read_text(encoding='utf-8'))
assert entries == stored['files'] and digest == stored['sourceDigest']
content = json.loads((CHECKPOINT / 'content/last-collection.json').read_text(encoding='utf-8'))
content_digest = hashlib.sha256(json.dumps(content, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()).hexdigest()
assert content_digest == '6dde071b2d6e6b280ca9ba6ce929bbdd1b42f4f128deba818fc1c32dd2b8e115'
(EVIDENCE / 'independent-source-identity.json').write_text(json.dumps({'source_digest': digest, 'source_files': entries, 'content_digest': content_digest}, indent=2), encoding='utf-8')
print('Independent source and content digests: PASS', flush=True)

tooling = WORK / 'tooling-replay'
assert not tooling.exists()
shutil.copytree(CHECKPOINT, tooling)
run('deterministic-build', [node, 'scripts/build.mjs'], cwd=tooling)
for name in ['dist/index.html','content/last-collection.mjs']:
    assert (tooling/name).read_bytes() == (CHECKPOINT/name).read_bytes(), name
run('transcript-inspector-regeneration', [node, 'scripts/generate-evidence.mjs'], cwd=tooling)
for name in ['M2_Interaction_Transcript.md', 'M2_Inspector_Trace.json']:
    assert (tooling/name).read_bytes() == (CHECKPOINT/name).read_bytes(), name
(EVIDENCE / 'deterministic-regeneration.json').write_text(json.dumps({'dist_build_byte_identical': True, 'sealed_content_module_byte_identical': True, 'transcript_byte_identical': True, 'inspector_trace_byte_identical': True}, indent=2), encoding='utf-8')
print('Deterministic build, transcript and inspector regeneration: PASS', flush=True)
