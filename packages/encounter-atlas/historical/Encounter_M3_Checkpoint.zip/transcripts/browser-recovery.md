# Generated M3 interaction transcript

Source run: `runs/browser-recovery.json`, SHA-256 `ec77d094458177ea633a54ceb3160118ab21f81a5e21189f956934d7c0668e38`.
Code: `M3-runtime-v1`, source digest `716a11c4efe9462e8ad60f16d6615ed8537811cf779d10dee424ef92558e3a94`.
Content: `M3-protective-shortcut-v1`, package digest `2ce9f61b996f17392a39c56f4005d8203b7940aa4974564fafa54d110e35ae8f`.
Generated from the actual browser Save run export after complete package, domain and command-journal validation. The text below is emitted by the implementation.

## Commit 1 · perform_action / physical

Command `command_5c4b690369ea40899483b760fccef929`, expected revision 0.

Physical result `result_0001`: performed; request action `action_0001`.

Received by `actor_0001`:
```text
{
  "authority": {
    "collectorId": "actor_0001",
    "itemId": "subject_0001",
    "ownerId": "actor_0003",
    "ticketId": "subject_0002",
    "verified": true
  },
  "conduct": "The valid collection ticket is shown and verified."
}
```

Received by `actor_0002`:
```text
{
  "authority": {
    "collectorId": "actor_0001",
    "itemId": "subject_0001",
    "ownerId": "actor_0003",
    "ticketId": "subject_0002",
    "verified": true
  },
  "conduct": "The valid collection ticket is shown and verified."
}
```

Actual effects:
```text
[]
```

Committed changes:
```text
[
  {
    "id": "result_0001",
    "outcome": "performed",
    "type": "physical_result"
  }
]
```

## Commit 2 · send_message

Command `command_a611fdc729cd4c87b0d588de5ed9b744`, expected revision 1.

Bound preview:
```text
Requests access to Collection record concerning Collection record.
Acknowledges the clerk’s work and communicates supportive concern about a defensible handover.
Social framing is emphatic.
```

Intake:
```text
Looks from the received material to the collector, holding a composed expression.
```

Delivery:
```text
Keeps the selected material in view and states the bounded response with a composed face.
The customer file contains case-handling material and unrelated private contact information. The relevant extract and permitted handling tray are available. Private contact values remain covered.
Social framing is measured.
```

Decision `decision_0001`; exact actor-local input and eligibility reasons are in the matching trace.

Committed changes:
```text
[]
```

## Commit 3 · send_message

Command `command_79d18c3f1474440cb82a670bfc450044`, expected revision 2.

Bound preview:
```text
Offers 100 minor money units for ordinary collection; no fee or debt is asserted.
Acknowledges the clerk’s work and communicates supportive concern about a defensible handover.
Social framing is emphatic.
```

Intake:
```text
Looks from the received material to the collector, holding a composed expression.
```

Delivery:
```text
Keeps the selected material in view and states the bounded response with a composed face.
No extra collection charge is due. I decline the ordinary payment offer as unnecessary. No money moves and no new debt or bribery judgment is created.
Social framing is measured.
```

Decision `decision_0002`; exact actor-local input and eligibility reasons are in the matching trace.

Committed changes:
```text
[]
```

## Commit 4 · send_message

Command `command_a67e3a0c696940d0a78bb89c0f44146b`, expected revision 3.

Bound preview:
```text
Asks where Nera’s green instrument case is. This is a request for location information, not a physical search.
Acknowledges the clerk’s work and communicates supportive concern about a defensible handover.
Social framing is emphatic.
```

Intake:
```text
Looks from the received material to the collector, holding a composed expression.
```

Delivery:
```text
Keeps the selected material in view and states the bounded response with a composed face.
I refer you to the recorded entry and the relevant inspection route rather than explaining the earlier movement.
Social framing is measured.
```

Decision `decision_0003`; exact actor-local input and eligibility reasons are in the matching trace.

Committed changes:
```text
[]
```

## Commit 5 · perform_action / physical

Command `command_156d4793028f4abe84d97a2ec2176631`, expected revision 4.

Physical result `result_0002`: performed; request action `action_0002`.

Received by `actor_0001`:
```text
{
  "conduct": "Performs the permitted inspect action.",
  "evidence": [
    {
      "form": "document",
      "label": "Recipient signature: unfilled",
      "markId": "subject_0010",
      "predicate": "recipient_signature",
      "roots": [
        {
          "id": "result_0002",
          "kind": "action_result"
        }
      ],
      "subjectId": "subject_0003",
      "value": "unfilled"
    }
  ],
  "references": [
    {
      "id": "subject_0003",
      "label": "Collection record"
    }
  ]
}
```

Received by `actor_0002`:
```text
{
  "conduct": "Sees the collector inspect the permitted extract; the small print is unreadable from here.",
  "evidence": [],
  "references": []
}
```

Actual effects:
```text
[]
```

Committed changes:
```text
[
  {
    "id": "result_0002",
    "outcome": "performed",
    "type": "physical_result"
  }
]
```

## Commit 6 · perform_action / physical

Command `command_254b61a877794389b0f58c03ae42cf50`, expected revision 5.

Physical result `result_0003`: performed; request action `action_0003`.

Received by `actor_0001`:
```text
{
  "conduct": "Performs the permitted search action.",
  "evidence": [
    {
      "form": "document",
      "label": "Drying tag 041 matches the case reference",
      "markId": "subject_0010",
      "predicate": "item_reference",
      "roots": [
        {
          "id": "result_0003",
          "kind": "action_result"
        }
      ],
      "subjectId": "subject_000c",
      "value": "subject_0001"
    },
    {
      "form": "document",
      "label": "Drying tag records internal drying, not recipient collection",
      "markId": "subject_0010",
      "predicate": "handling_type",
      "roots": [
        {
          "id": "result_0003",
          "kind": "action_result"
        }
      ],
      "subjectId": "subject_000c",
      "value": "internal_drying"
    }
  ],
  "references": [
    {
      "id": "subject_000c",
      "label": "Numbered drying tag"
    },
    {
      "id": "subject_0001",
      "label": "Nera’s green instrument case"
    }
  ]
}
```

Received by `actor_0004`:
```text
{
  "conduct": "Sees the collector search the permitted handling tray; does not read the tag.",
  "evidence": [],
  "references": []
}
```

Actual effects:
```text
[]
```

Committed changes:
```text
[
  {
    "id": "result_0003",
    "outcome": "performed",
    "type": "physical_result"
  }
]
```

## Commit 7 · perform_action / switch_partner

Command `command_b20ab873a14c47338588ed04cc3ad242`, expected revision 6.

Committed changes:
```text
[
  {
    "partnerId": "actor_0004",
    "type": "switch_partner"
  }
]
```

## Commit 8 · send_message

Command `command_653ae17aba7b4bd798f992030820e709`, expected revision 7.

Bound preview:
```text
Asks where Nera’s green instrument case is. This is a request for location information, not a physical search.
Acknowledges the clerk’s work and communicates supportive concern about a defensible handover.
Social framing is emphatic.
```

Intake:
```text
Looks from the received material to the collector, holding a composed expression.
```

Delivery:
```text
Keeps the selected material in view and states the bounded response with a composed face.
A wrapped green case moved toward the partition; its exact identity was not established by that sighting
It may have been an exception. I did not see the damp seam, final cupboard, or purpose; that interpretation is not a witnessed fact.
This report does not prove a completed collection.
Social framing is measured.
```

Decision `decision_0004`; exact actor-local input and eligibility reasons are in the matching trace.

Committed changes:
```text
[]
```

## Commit 9 · perform_action / switch_partner

Command `command_986cb615bca842cf8c558d25cf03e5a2`, expected revision 8.

Committed changes:
```text
[
  {
    "partnerId": "actor_0002",
    "type": "switch_partner"
  }
]
```

## Commit 10 · send_message

Command `command_4e937ac0d6184c5fabf1b837b15e8668`, expected revision 9.

Bound preview:
```text
Shows only the selected evidence below, concerning Case-handling scope. Showing it does not transfer the object.
Recipient signature: unfilled
Drying tag 041 matches the case reference
Drying tag records internal drying, not recipient collection
A wrapped green case moved toward the partition; its exact identity was not established by that sighting
Acknowledges the clerk’s work and communicates supportive concern about a defensible handover.
Social framing is emphatic.
```

Intake:
```text
Looks from the received material to the collector, holding a composed expression.
```

Delivery:
```text
Keeps the selected material in view and states the bounded response with a composed face.
A supervised comparison limited to the case-handling evidence is available. Accepting it is permission; choose the physical comparison action to perform it.
Social framing is measured.
```

Decision `decision_0005`; exact actor-local input and eligibility reasons are in the matching trace.

Committed changes:
```text
[]
```

## Commit 11 · perform_action / physical

Command `command_d2f5fd49b8d7403c8aaa2ba4ea534818`, expected revision 10.

Physical result `result_0004`: performed; request action `action_0004`.

Received by `actor_0001`:
```text
{
  "comparison": {
    "complete": true,
    "itemId": "subject_0001",
    "serviceId": "service_0001"
  },
  "conduct": "Performs the permitted compare action.",
  "evidence": [
    {
      "form": "document",
      "label": "Recipient signature: unfilled",
      "markId": "subject_0010",
      "predicate": "recipient_signature",
      "roots": [
        {
          "id": "result_0004",
          "kind": "action_result"
        }
      ],
      "subjectId": "subject_0003",
      "value": "unfilled"
    },
    {
      "form": "document",
      "label": "Drying tag 041 matches the case reference",
      "markId": "subject_0010",
      "predicate": "item_reference",
      "roots": [
        {
          "id": "result_0004",
          "kind": "action_result"
        }
      ],
      "subjectId": "subject_000c",
      "value": "subject_0001"
    },
    {
      "form": "document",
      "label": "Drying tag records internal drying, not recipient collection",
      "markId": "subject_0010",
      "predicate": "handling_type",
      "roots": [
        {
          "id": "result_0004",
          "kind": "action_result"
        }
      ],
      "subjectId": "subject_000c",
      "value": "internal_drying"
    },
    {
      "form": "document",
      "label": "Case is in dry storage",
      "markId": "subject_0010",
      "predicate": "storage_location",
      "roots": [
        {
          "id": "result_0004",
          "kind": "action_result"
        }
      ],
      "subjectId": "subject_0001",
      "value": "subject_000f"
    },
    {
      "form": "document",
      "label": "Original collected entry meant removed from the rack",
      "markId": "subject_0010",
      "predicate": "original_entry_meaning",
      "roots": [
        {
          "id": "result_0004",
          "kind": "action_result"
        }
      ],
      "subjectId": "subject_0003",
      "value": "removed_from_rack"
    },
    {
      "form": "document",
      "label": "Separate hauling obligation: already paid",
      "markId": "subject_0010",
      "predicate": "hauling_obligation_status",
      "roots": [
        {
          "id": "result_0004",
          "kind": "action_result"
        }
      ],
      "subjectId": "subject_0001",
      "value": "already_paid"
    }
  ],
  "references": [
    {
      "id": "subject_0003",
      "label": "Collection record"
    },
    {
      "id": "subject_000c",
      "label": "Numbered drying tag"
    },
    {
      "id": "subject_0001",
      "label": "Nera’s green instrument case"
    },
    {
      "id": "subject_000f",
      "label": "Dry storage"
    }
  ]
}
```

Received by `actor_0002`:
```text
{
  "comparison": {
    "complete": true,
    "itemId": "subject_0001",
    "serviceId": "service_0001"
  },
  "conduct": "Reads the selected case-handling evidence in the supervised comparison.",
  "evidence": [
    {
      "form": "document",
      "label": "Recipient signature: unfilled",
      "markId": "subject_0010",
      "predicate": "recipient_signature",
      "roots": [
        {
          "id": "result_0004",
          "kind": "action_result"
        }
      ],
      "subjectId": "subject_0003",
      "value": "unfilled"
    },
    {
      "form": "document",
      "label": "Drying tag 041 matches the case reference",
      "markId": "subject_0010",
      "predicate": "item_reference",
      "roots": [
        {
          "id": "result_0004",
          "kind": "action_result"
        }
      ],
      "subjectId": "subject_000c",
      "value": "subject_0001"
    },
    {
      "form": "document",
      "label": "Drying tag records internal drying, not recipient collection",
      "markId": "subject_0010",
      "predicate": "handling_type",
      "roots": [
        {
          "id": "result_0004",
          "kind": "action_result"
        }
      ],
      "subjectId": "subject_000c",
      "value": "internal_drying"
    },
    {
      "form": "document",
      "label": "Recipient signature: unfilled",
      "markId": "subject_0010",
      "predicate": "recipient_signature",
      "roots": [
        {
          "id": "result_0002",
          "kind": "action_result"
        }
      ],
      "subjectId": "subject_0003",
      "value": "unfilled"
    },
    {
      "form": "document",
      "label": "Drying tag 041 matches the case reference",
      "markId": "subject_0010",
      "predicate": "item_reference",
      "roots": [
        {
          "id": "result_0003",
          "kind": "action_result"
        }
      ],
      "subjectId": "subject_000c",
      "value": "subject_0001"
    },
    {
      "form": "document",
      "label": "Drying tag records internal drying, not recipient collection",
      "markId": "subject_0010",
      "predicate": "handling_type",
      "roots": [
        {
          "id": "result_0003",
          "kind": "action_result"
        }
      ],
      "subjectId": "subject_000c",
      "value": "internal_drying"
    },
    {
      "form": "report",
      "label": "A wrapped green case moved toward the partition; its exact identity was not established by that sighting",
      "markId": null,
      "predicate": "movement_direction",
      "roots": [
        {
          "id": "event_0002",
          "kind": "event"
        }
      ],
      "subjectId": "subject_0011",
      "value": "subject_000a"
    }
  ],
  "references": [
    {
      "id": "subject_0003",
      "label": "Collection record"
    },
    {
      "id": "subject_000c",
      "label": "Numbered drying tag"
    },
    {
      "id": "subject_0001",
      "label": "Nera’s green instrument case"
    }
  ]
}
```

Actual effects:
```text
[
  {
    "payload": {
      "serviceId": "service_0001"
    },
    "type": "complete_comparison"
  }
]
```

Intake:
```text
Looks from the received material to the collector, holding a composed expression.
```

Delivery:
```text
Keeps the selected material in view and states the bounded response with a composed face.
The actual supervised comparison supports the authorized release. Review the exact current handover terms and confirm deliberately. Permission or saying Yes does not hand over the item.
Social framing is measured.
```

Decision `decision_0006`; exact actor-local input and eligibility reasons are in the matching trace.

Committed changes:
```text
[
  {
    "id": "result_0004",
    "outcome": "performed",
    "type": "physical_result"
  },
  {
    "offerId": "offer_0001",
    "revision": 1,
    "type": "offer_prepared"
  }
]
```

## Commit 12 · send_message

Command `command_8fd7087c4f0c490aa6eb495c73faf479`, expected revision 11.

Bound preview:
```text
Acknowledges handover proposal offer_0001, version 1. This does not confirm or execute its material terms.
Acknowledges the clerk’s work and communicates supportive concern about a defensible handover.
Social framing is emphatic.
```

Intake:
```text
Looks from the received material to the collector, holding a composed expression.
```

Delivery:
```text
Keeps the selected material in view and states the bounded response with a composed face.
Your acknowledgment does not execute the proposal. Use the separate exact handover confirmation if you accept the current terms.
Social framing is measured.
```

Decision `decision_0007`; exact actor-local input and eligibility reasons are in the matching trace.

Committed changes:
```text
[]
```

## Commit 13 · perform_action / physical

Command `command_648e8d0fa29244db89af9db19c8b3a28`, expected revision 12.

Physical result `result_0005`: performed; request action `action_0005`.

Received by `actor_0001`:
```text
{
  "conduct": "The correction is recorded as a new revision; the original shorthand remains.",
  "recordCorrection": {
    "recordId": "subject_0003",
    "text": "Original “collected” meant removal from the rack for internal drying; recipient handover is recorded separately."
  }
}
```

Received by `actor_0002`:
```text
{
  "conduct": "The correction is recorded as a new revision; the original shorthand remains.",
  "recordCorrection": {
    "recordId": "subject_0003",
    "text": "Original “collected” meant removal from the rack for internal drying; recipient handover is recorded separately."
  }
}
```

Actual effects:
```text
[
  {
    "payload": {
      "recordId": "subject_0003",
      "text": "Original “collected” meant removal from the rack for internal drying; recipient handover is recorded separately."
    },
    "type": "correct_record"
  }
]
```

Committed changes:
```text
[
  {
    "id": "result_0005",
    "outcome": "performed",
    "type": "physical_result"
  }
]
```

## Commit 14 · perform_action / confirm_offer

Command `command_a1ef6388863c4333b2b1d21bac3d8a98`, expected revision 13.

Physical result `result_0006`: performed; request action `action_0006`.

Received by `actor_0001`:
```text
{
  "conduct": "The exact confirmed handover occurs. The collector receives custody; ownership is unchanged.",
  "handover": {
    "complete": true,
    "holderId": "actor_0001",
    "itemId": "subject_0001",
    "offerId": "offer_0001",
    "offerRevision": 1,
    "ownerId": "actor_0003",
    "paidMinor": 0
  }
}
```

Received by `actor_0002`:
```text
{
  "conduct": "The exact confirmed handover occurs. The collector receives custody; ownership is unchanged.",
  "handover": {
    "complete": true,
    "holderId": "actor_0001",
    "itemId": "subject_0001",
    "offerId": "offer_0001",
    "offerRevision": 1,
    "ownerId": "actor_0003",
    "paidMinor": 0
  }
}
```

Actual effects:
```text
[
  {
    "payload": {
      "fromId": "subject_0007",
      "itemId": "subject_0001",
      "ownerId": "actor_0003",
      "toId": "actor_0001"
    },
    "type": "custody_transfer"
  },
  {
    "payload": {
      "itemId": "subject_0001"
    },
    "type": "complete_recovery"
  }
]
```

Committed changes:
```text
[
  {
    "payload": {
      "fromId": "subject_0007",
      "itemId": "subject_0001",
      "ownerId": "actor_0003",
      "toId": "actor_0001"
    },
    "type": "custody_transfer"
  },
  {
    "payload": {
      "itemId": "subject_0001"
    },
    "type": "complete_recovery"
  }
]
```

## Final independent outcomes

```text
{
  "recovered": true,
  "serviceOpen": true,
  "ownerId": "actor_0003",
  "holderId": "actor_0001",
  "quantity": 1,
  "balances": {
    "actor_0001": 1200,
    "actor_0002": 0,
    "actor_0004": 0
  },
  "recordCorrected": true,
  "privateDisclosed": false
}
```
Repair/visit state: `[{"holderId":"actor_0002","repairUsed":false,"restricted":false,"restrictedOrRepaired":false,"restrictionMessageId":null,"serviceId":"service_0001","warningMessageId":null}]`.
Technical defects: 0. Canonical observations: 42.
Private contact values are absent from player knowledge and actual decision inputs. Author/package exports retain synthetic fixture truth. Recovery, spending, privacy and record correction remain distinct.
