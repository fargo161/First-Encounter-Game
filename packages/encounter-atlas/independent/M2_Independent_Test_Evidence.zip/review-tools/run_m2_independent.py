import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent.parent
WORK = ROOT / 'work/m2-independent-review'
EVIDENCE = WORK / 'evidence'
test_file = ROOT / 'outputs/M2_Independent_Contract_Tests.test.mjs'
before = hashlib.sha256(test_file.read_bytes()).hexdigest()
env = dict(os.environ)
env.update({'ENCOUNTER_CHECKPOINT': str(WORK / 'checkpoint'), 'M2_BROWSER_EVIDENCE': str(EVIDENCE)})
argv = [shutil.which('node'), '--test', '--test-reporter=tap', str(test_file)]
result = subprocess.run(argv, cwd=ROOT, env=env, capture_output=True, text=True, encoding='utf-8', errors='replace')
log = f'CWD: {ROOT}\nENCOUNTER_CHECKPOINT: {env["ENCOUNTER_CHECKPOINT"]}\nM2_BROWSER_EVIDENCE: {env["M2_BROWSER_EVIDENCE"]}\nCOMMAND: {subprocess.list2cmdline(argv)}\nEXIT: {result.returncode}\n\nSTDOUT:\n{result.stdout}\nSTDERR:\n{result.stderr}'
(EVIDENCE / 'independent-m2-tests.tap').write_text(log, encoding='utf-8')
counts = {k: int(v) for k,v in re.findall(r'^# (tests|pass|fail|skipped|cancelled|todo) (\d+)$', result.stdout, re.M)}
assert hashlib.sha256(test_file.read_bytes()).hexdigest() == before
commands_file = EVIDENCE / 'commands.json'
commands = json.loads(commands_file.read_text())
commands.append({'label': 'independent-m2-tests', 'cwd': str(ROOT), 'argv': argv, 'env': {k:env[k] for k in ['ENCOUNTER_CHECKPOINT','M2_BROWSER_EVIDENCE']}, 'test_sha256': before, 'exit': result.returncode, 'counts': counts})
commands_file.write_text(json.dumps(commands, indent=2), encoding='utf-8')
print(json.dumps({'exit': result.returncode, 'counts': counts, 'unchanged_test_sha256': before}, indent=2))
assert result.returncode == 0
