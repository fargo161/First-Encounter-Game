# M0/M1 — Fresh results and scope

Date: 2026-10-17, America/New_York. Builder validation only; **no independent tester verdict** and **no M2 execution**.

## Exact source/content identity

The review export is `Encounter_M0_M1_Checkpoint.zip`, identified by its adjacent `Encounter_M0_M1_Checkpoint.identity.json`. That external identity gives the exact archive SHA-256 and every member's bytes/hash without a self-referential checksum. The frozen archive includes the exact reports, logs, source and reference bytes used here.

- Code revision: `M1-contract-v1`, executable-source digest **ff27bc93bc7b6105470555b73224f634f72bcf79a7a7e4e29e66264c2b3b7a26**. Algorithm and component hashes: `scripts/source-identity.py` and `evidence/M1_source_identity.json`.
- Neutral content: `tests/fixtures.mjs`, SHA-256 **f4ddba46ab2804f0358d78c07d30c9c26adca42ea825b2744fee780ddb8b85e4**. Its package reference is a synthetic test token, not authored Last Collection content. No M2 scenario revision exists yet.
- Legacy executable: SHA-256 **c9b50efed0ead41d0faa69757969feff8ced1fbc22187c11989aa9ff2dd21eb9**.
- M0-only archive: `Encounter_M0_Checkpoint.zip`, SHA-256 **688f3e02414002574a43353ea1f8171a5ef9e11ddaa6e2dac25de93f7e828930**. It was saved before M1 source was created.

The workspace was not Git-backed. No Git commit or remote is claimed. All four originals were rehashed after implementation; their copied reference hashes still match exactly (`evidence/source_preservation.json`).

## Environment and commands actually executed

Windows, PowerShell shell; Git 2.55.0.windows.3; Node v24.18.0; npm 11.16.0; Python 3.12.0. No dependency installation or runtime network call was needed.

Workspace inventory used `Get-ChildItem -Force`, `rg --files --hidden -g '!.git' .`, ancestor `AGENTS.md` existence checks, `Get-Command node,npm,python,py,git,rg`, `git --version`, `git rev-parse --show-toplevel`, `node --version`, `npm --version`, and `python --version`. Explicit source reads used `Get-Content -LiteralPath`, then bounded `Select-Object` ranges to recover tool-output truncation. Source metadata and preservation used `Get-Item`, `Get-FileHash -Algorithm SHA256`, and byte-preserving `Copy-Item`. No missing historical test archive was found or presumed recovered.

From the checkpoint root:

```powershell
node scripts/audit-baseline.cjs
npm test
python scripts/source-identity.py
python scripts/snapshot.py Encounter_M0_M1_Checkpoint
python scripts/verify-checkpoint.py ../Encounter_M0_M1_Checkpoint.identity.json
```

The earlier M0 export used `python scripts/snapshot.py Encounter_M0_Checkpoint`. Raw test outputs are in `evidence/M0_baseline_checks.txt` and `evidence/M1_contract_tests.txt`. The final archive verification and an extracted-copy test run are reported in the adjacent `Encounter_M0_M1_Verification.txt`, outside the immutable ZIP.

## Automated results

| Fresh execution | Passed | Failed | Practical limit |
|---|---:|---:|---|
| M0 legacy audit | 7 | 0 | Full inline-script syntax compilation plus non-DOM legacy components evaluated in Node VM; no browser run. One check intentionally confirms the overbroad legacy public projection. |
| M1 contract suite, final source revision above | 36 | 0 | Shared record/view contracts, neutral processors and atomic envelope; no connected Last Collection gameplay. Zero skipped/cancelled/todo. |

The M1 suite first passed 31 checks; it was expanded after boundary review, passed 35, then passed 36 after adding a shared-envelope NPC reply shape test. The saved final log contains the 36-check run. Those earlier runs are not extra distinct acceptance cases.

| Requirement exercised | Actual M1 evidence | Not claimed |
|---|---|---|
| Kickoff §3.2 retry / identity conflict / stale | Three named required runtime tests, plus key-order, new-repeat, persistence and early-conflict tests. Exact retry returns its stored receipt before stale checks. | Network/distributed execution. |
| No technical gameplay consequences | Preflight failure, post-stage failure and invariant-failure tests retain the original run; hidden exception text is suppressed. | Scenario-domain validation not yet written. |
| Valid refusal may still be heard | Neutral processor commits a `message_received` event and refusal result, with no material effects. | Tamsin's refusal policy or negotiations. |
| NPC information boundary | Private metadata perturbation gives identical complete listener input; closed outward fields reject selector/template/cache additions and nested metadata in substantive values. | M2 semantic compiler, all caches, actual decision/response equality end to end. |
| Source-linked PERCEIVED | Both a received historical event ID and an action-result ID retrieve only received fragments; hidden destination, purpose, print and contact canaries stay absent. | A full sensory system. |
| Claims differ from facts | Assertion must match local speech observation; changed, uncommunicated assertion is filtered; no physical incident or world fact is synthesized. | Full belief revision, numeric support or intentional-deception diagnosis. |
| Permission and physical-result boundary | A permission record reveals no result; a neutral matched result stages once, rejects mismatches/changed identity/second result and separates conduct from print. | The actual permitted inspection action/resolver. |
| Read-only views and actor locality | Frozen detached preview/history/author copies; refresh leaves input unchanged; absent/unaddressed actor learns nothing. | Actual inspector UI, player menus, playback or partner switching. |
| Portable identity | Arbitrary actor IDs, display renaming and absent actor work through the same view code. | A portable playable policy or full neutral gameplay scenario. |
| Future vocabulary / common message | All 20 names, six player coverage act types, three settings; NPC reply record shares canonical envelope and hides its own expression selection. | Six implemented acts, any completed semantic BASED coverage, NPC initiation or authored performances. |

These tests are relevant contract-level portions of LC-T04, 09–13, 28, 38, 40, 46–47, 57, 59, 67–68 and the kickoff's explicit identity requirements. They are **not** full LC-T pass declarations. No full set of 69 tests or 360 coverage cases was executed. The historical **253 / 29** totals remain historical reports only.

## Static review and checks not run

Static review covered every supplied file, the named legacy functions, source authority, the v2.1 reading rule, superseded reaction/knowledge/seat semantics, exact new update order and the M1 view boundary. Four source-preservation comparisons succeeded. The first PowerShell metadata pipeline had a parser error and was corrected; that was an inventory command issue, not a gameplay failure.

No browser/manual UI or human playtesting was performed. No complete M2 transcript or matching gameplay inspector trace exists, because producing one would require crossing the M1 gate. No browser build/launch, double-click behavior, localStorage, downloads/imports, file menus, complete Intake/Delivery, skipped/replayed presentation, full domain save validation, old-save rejection UI, semantic compilation, salience invariance, first-request behavior or real policy portability has been tested. Those remain explicit M2/later requirements.

No failing case was observed in the executed final suites. This does not establish absence of defects outside those tests. Runtime domain hooks, authoritative detail grants and curated wording remain trusted integration responsibilities that the independent tester should challenge. The JSON envelope validator alone is not a full game-save validator or proof that future callbacks preserve every invariant.

## Completed

M0 actual inventory, immutable reference preservation, baseline reuse audit, seven fresh checks, honest missing-source report and exact M0 export. M1 narrow executable records/projections, neutral action boundary, atomic command/journal path, chosen retry order, contract note and 36 fresh builder tests. Independent review has a precise self-contained saved checkpoint.

## Partial

M1 alignment is prepared by the builder; tester agreement/feedback remains pending. Package/run and physical-result **contracts** are executable, while scenario-domain validation and processing are reserved for M2. This is not a partial M2 implementation.

## Blocked

M2 entry is blocked by the explicitly requested review gate, kickoff §7.9. No independent tester has reviewed this saved M0/M1 snapshot and supplied feedback; Teddy has not explicitly waived that checkpoint. No missing technical input currently blocks M0/M1. Builder self-tests do not clear the gate.

## Deferred

All M2 compiler/content/policy/resolver/browser integration, runnable build, actual generated transcript and causal UI trace await gate clearance. M3 and later, full Last Collection recovery, Seed B negotiation, closure/repair system, full transactions, all 360 BASED coverage cases, full Assembler, combat/theft/stealth, promises engine, runtime AI, finished media, live-run editing, old-save conversion and additional agents remain outside this execution. No additional agent/tester was launched or messaged.

## Design questions discovered

No unresolved owner-facing choice prevents review of M1. The missing-preview fallback specifically requires owner confirmation before M3, even though the approval record describes it as approved; kickoff §3.1 is the higher-authority correction. M2 integration must verify actual offline packaging/storage behavior and domain record/content validation, then report real results. Its proposed file layout, role bindings, scalar schemas and deterministic tie order remain reviewable builder choices in the contract note.
