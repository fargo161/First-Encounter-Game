import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent / 'm1-review'
CHECKPOINT = ROOT / 'checkpoint'
EVIDENCE = ROOT / 'evidence'
BUILDER = Path(r'C:\Users\mcdon\Documents\Codex\2026-10-17\execute-encounter-codex-lead-builder-m0')
IDENTITY = BUILDER / 'outputs/Encounter_M0_M1_Checkpoint.identity.json'
records = []

def run(label, args, cwd=CHECKPOINT):
    result = subprocess.run([str(a) for a in args], cwd=cwd, capture_output=True, text=True, encoding='utf-8', errors='replace')
    log = f'CWD: {cwd}\nCOMMAND: {subprocess.list2cmdline([str(a) for a in args])}\nEXIT: {result.returncode}\n\nSTDOUT:\n{result.stdout}\nSTDERR:\n{result.stderr}'
    (EVIDENCE / (label + '.txt')).write_text(log, encoding='utf-8')
    records.append({'label': label, 'cwd': str(cwd), 'argv': [str(a) for a in args], 'exit': result.returncode})
    print(f'{label}: exit {result.returncode}')
    return result

node = shutil.which('node')
npm = shutil.which('npm.cmd')
git = shutil.which('git')
assert node and npm and git
for label, args in [('node-version', [node, '--version']), ('npm-version', [npm, '--version']), ('python-version', [sys.executable, '--version']), ('git-version', [git, '--version'])]:
    run(label, args)
run('builder-git-root', [git, 'rev-parse', '--show-toplevel'], BUILDER)
run('builder-git-status', [git, 'status', '--short'], BUILDER)
run('baseline-audit', [node, 'scripts/audit-baseline.cjs'])
run('builder-contract-tests', [npm, 'test'])
run('builder-archive-verifier', [sys.executable, 'scripts/verify-checkpoint.py', IDENTITY])

paths = [CHECKPOINT / 'package.json']
for folder in ('src', 'tests', 'scripts'):
    paths.extend(p for p in (CHECKPOINT / folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
entries = [{'path': p.relative_to(CHECKPOINT).as_posix(), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(paths)]
digest = hashlib.sha256(json.dumps(entries, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
stored = json.loads((CHECKPOINT / 'evidence/M1_source_identity.json').read_text(encoding='utf-8'))
assert entries == stored['files'] and digest == stored['sourceDigest']
(EVIDENCE / 'independent-source-digest.json').write_text(json.dumps({'sourceDigest': digest, 'files': entries, 'matches_stored': True}, indent=2), encoding='utf-8')
print('independent-source-digest: PASS ' + digest)

tooling = ROOT / 'tooling-replay'
assert not tooling.exists()
shutil.copytree(CHECKPOINT, tooling)
run('builder-source-identity-regenerated', [sys.executable, 'scripts/source-identity.py'], tooling)
run('builder-snapshot-regenerated', [sys.executable, 'scripts/snapshot.py', 'Encounter_M0_M1_Checkpoint'], tooling)
rebuilt = ROOT / 'Encounter_M0_M1_Checkpoint.zip'
assert hashlib.sha256(rebuilt.read_bytes()).hexdigest() == json.loads(IDENTITY.read_text())['sha256'], 'Regenerated archive differs'
print('regenerated-snapshot-byte-identity: PASS')
(EVIDENCE / 'commands.json').write_text(json.dumps({'time_utc': datetime.now(timezone.utc).isoformat(), 'commands': records}, indent=2), encoding='utf-8')
