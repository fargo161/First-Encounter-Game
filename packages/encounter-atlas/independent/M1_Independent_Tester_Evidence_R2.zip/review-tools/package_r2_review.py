import hashlib
import json
from pathlib import Path
import re
import zipfile

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'outputs'
WORK = ROOT / 'work/r2-review'
EVIDENCE = WORK / 'evidence'
SOURCE = Path(r'C:\Users\mcdon\Documents\Codex\2026-10-17\execute-encounter-codex-lead-builder-m0\outputs')
sha = lambda data: hashlib.sha256(data).hexdigest()
verification = json.loads((EVIDENCE / 'checkpoint-verification.json').read_text())
preserved = []
for label, archive_name, extraction, expanded in [
    ('R1', 'Encounter_M0_M1_Checkpoint', WORK / 'r1-control', SOURCE / 'Encounter_M0_M1'),
    ('R2', 'Encounter_M0_M1_Checkpoint_R2', WORK / 'checkpoint', SOURCE / 'Encounter_M0_M1_R2'),
]:
    identity_file = SOURCE / (archive_name + '.identity.json')
    identity = json.loads(identity_file.read_text())
    archive = SOURCE / (archive_name + '.zip')
    expected_sha = verification['r1_sha256'] if label == 'R1' else verification['r2_sha256']
    assert sha(archive.read_bytes()) == identity['sha256'] == expected_sha
    for member in identity['files']:
        for folder in [extraction, expanded]:
            data = (folder / member['path']).read_bytes()
            assert len(data) == member['bytes'] and sha(data) == member['sha256'], str(folder / member['path'])
    preserved.append({'checkpoint': label, 'archive_sha256': expected_sha, 'manifest_sha256': sha(identity_file.read_bytes()), 'unchanged_extracted_members': len(identity['files']), 'unchanged_builder_members': len(identity['files'])})
assert preserved[0]['manifest_sha256'] == '0a468470e3c76906a88a192c4898df12cff2d58fb77e64aeb51c49f94a4029e0'
assert preserved[1]['manifest_sha256'] == verification['r2_identity_sha256']
for entry in verification['unchanged_tester_evidence']:
    assert sha((OUT / entry['name']).read_bytes()) == entry['sha256']
original_refs = json.loads((WORK / 'checkpoint/evidence/source_preservation.json').read_text())['original_references']
for entry in original_refs:
    assert sha(Path(entry['source']).read_bytes()) == entry['sha256']
(EVIDENCE / 'final-preservation-check.json').write_text(json.dumps({'result': 'PASS', 'checkpoints': preserved, 'previous_tester_evidence_unchanged': True, 'original_reference_matches': len(original_refs)}, indent=2), encoding='utf-8')

def counts(filename):
    value = (EVIDENCE / filename).read_text(encoding='utf-8')
    return {key: int(number) for key, number in re.findall(r'^[#ℹ] (tests|pass|fail|cancelled|skipped|todo) (\d+)\s*$', value, re.M)}
results = {
    'r1_defect_control': counts('r1-original-defects.txt'),
    'r2_defect_retest': counts('r2-original-defects.txt'),
    'r2_builder_suite': counts('r2-builder-contract-tests.txt'),
    'r2_independent_suite': counts('r2-unchanged-independent-suite.txt'),
}
assert results['r1_defect_control']['fail'] == 2 and results['r1_defect_control']['pass'] == 0
assert results['r2_defect_retest']['pass'] == 2 and results['r2_defect_retest']['fail'] == 0
assert results['r2_builder_suite']['pass'] == 38 and results['r2_builder_suite']['fail'] == 0
assert results['r2_independent_suite']['pass'] == 22 and results['r2_independent_suite']['fail'] == 0
baseline_log = (EVIDENCE / 'r2-baseline-audit.txt').read_text(encoding='utf-8')
assert '"checksPassed": 7' in baseline_log and '"checksFailed": 0' in baseline_log
results['r2_baseline_audit'] = {'pass': 7, 'fail': 0}
(EVIDENCE / 'results.json').write_text(json.dumps(results, indent=2), encoding='utf-8')

report = OUT / 'M1_Independent_Tester_Review_R2.md'
text = report.read_text(encoding='utf-8')
expected_sections = ['Checkpoint reviewed', 'Files inspected', 'Commands actually executed', 'M0 findings', 'M1 contract findings', 'Passed checks', 'Defects', 'Questions/conflicts requiring owner or lead action', 'Verdict']
assert re.findall(r'^## \d+\. (.+)$', text, re.M) == expected_sections
assert '**Verdict: READY FOR M2**' in text and '**READY FOR M2**' in text
assert verification['r2_sha256'] in text
assert 'M2 testing was not begun' in text

items = [
    (report.name, report),
    ('M1_Independent_Contract_Tests.test.mjs', OUT / 'M1_Independent_Contract_Tests.test.mjs'),
    ('inputs/Encounter_M0_M1_Checkpoint_R2.zip', SOURCE / 'Encounter_M0_M1_Checkpoint_R2.zip'),
    ('inputs/Encounter_M0_M1_Checkpoint_R2.identity.json', SOURCE / 'Encounter_M0_M1_Checkpoint_R2.identity.json'),
    ('inputs/M1_Defect_Remediation_Report.md', SOURCE / 'Encounter_M0_M1_R2/M1_Defect_Remediation_Report.md'),
    ('previous/M1_Independent_Tester_Review.md', OUT / 'M1_Independent_Tester_Review.md'),
    ('previous/M1_Independent_Tester_Evidence.zip', OUT / 'M1_Independent_Tester_Evidence.zip'),
]
items += [('evidence/' + file.name, file) for file in sorted(EVIDENCE.iterdir()) if file.is_file()]
items += [('review-tools/' + name, ROOT / 'work' / name) for name in ['verify_r2_checkpoint.py', 'run_r2_checks.py', 'package_r2_review.py']]
manifest = [{'path': name, 'bytes': file.stat().st_size, 'sha256': sha(file.read_bytes())} for name, file in items]
bundle = OUT / 'M1_Independent_Tester_Evidence_R2.zip'
with zipfile.ZipFile(bundle, 'w', zipfile.ZIP_DEFLATED) as z:
    for name, file in items:
        z.write(file, name)
    z.writestr('review-manifest.json', json.dumps({'checkpoint_sha256': verification['r2_sha256'], 'verdict': 'READY FOR M2', 'members': manifest}, indent=2))
with zipfile.ZipFile(bundle) as z:
    assert z.testzip() is None
    assert len(z.namelist()) == len(manifest) + 1
    for entry in manifest:
        data = z.read(entry['path'])
        assert len(data) == entry['bytes'] and sha(data) == entry['sha256']
print(json.dumps({'report': str(report), 'evidence_bundle': str(bundle), 'bundle_bytes': bundle.stat().st_size, 'bundle_members': len(manifest) + 1, 'results': results, 'preservation': 'PASS', 'artifact_qa': 'PASS'}, indent=2))
