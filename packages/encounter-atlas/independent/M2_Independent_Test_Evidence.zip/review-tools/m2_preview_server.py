from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import os

root = Path(__file__).resolve().parent / 'm2-independent-review/checkpoint/dist'
assert root.is_dir()
server = ThreadingHTTPServer(('127.0.0.1', 0), partial(SimpleHTTPRequestHandler, directory=str(root)))
print(f'Local: http://127.0.0.1:{server.server_port}/', flush=True)
print(f'PID: {os.getpid()}; serving unchanged verified dist: {root}', flush=True)
try:
    server.serve_forever()
except KeyboardInterrupt:
    pass
finally:
    server.server_close()
