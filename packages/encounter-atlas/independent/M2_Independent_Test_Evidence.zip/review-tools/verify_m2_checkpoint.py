import hashlib
import json
from pathlib import Path, PurePosixPath
import zipfile

ROOT = Path(__file__).resolve().parent.parent
WORK = ROOT / 'work/m2-independent-review'
TARGET = WORK / 'checkpoint'
EVIDENCE = WORK / 'evidence'
EVIDENCE.mkdir(parents=True, exist_ok=True)
HANDOFF = Path(r'C:\Users\mcdon\Downloads\Encounter_M2_Tester_Handoff')
archive = HANDOFF / 'Encounter_M2_Checkpoint.zip'
identity_file = HANDOFF / 'Encounter_M2_Checkpoint.identity.json'
identity = json.loads(identity_file.read_text(encoding='utf-8-sig'))
sha = lambda b: hashlib.sha256(b).hexdigest()
assert archive.name == identity['snapshot']
assert sha(archive.read_bytes()) == identity['sha256']
expected = {f['path']: f for f in identity['files']}
assert len(expected) == len(identity['files'])
with zipfile.ZipFile(archive) as z:
    names = z.namelist()
    assert len(names) == len(set(n.casefold() for n in names)) and set(names) == set(expected)
    for name in names:
        p = PurePosixPath(name)
        assert not p.is_absolute() and '..' not in p.parts and ':' not in name and '\\' not in name
        b = z.read(name)
        assert len(b) == expected[name]['bytes'] and sha(b) == expected[name]['sha256'], name
    assert z.testzip() is None
    assert not TARGET.exists()
    z.extractall(TARGET)
loose = []
for name in ['README.md', 'Test_Results_and_Scope.md', 'M2_Interaction_Transcript.md']:
    assert (HANDOFF / name).read_bytes() == (TARGET / name).read_bytes()
    loose.append({'name': name, 'sha256': sha((HANDOFF / name).read_bytes())})
r2_source = Path(r'C:\Users\mcdon\Documents\Codex\2026-10-17\execute-encounter-codex-lead-builder-m0\outputs')
r2zip = r2_source / 'Encounter_M0_M1_Checkpoint_R2.zip'
assert sha(r2zip.read_bytes()) == identity['baseline']['sha256'] == '47a879c74ac7f684ff5d3d7d1de742d800d8d5cd801fe833234707ec66be555d'
r2 = json.loads((r2_source / 'Encounter_M0_M1_Checkpoint_R2.identity.json').read_text())
r2files = {f['path']: f for f in r2['files']}
assert (TARGET / 'reference/R2_Baseline.identity.json').read_bytes() == (r2_source / 'Encounter_M0_M1_Checkpoint_R2.identity.json').read_bytes()
unchanged = []
for name in ['src/contracts.mjs', 'src/runtime.mjs', 'src/views.mjs', 'src/action-boundary.mjs', 'tests/fixtures.mjs', 'tests/runtime.test.mjs', 'tests/views.test.mjs', 'tests/identity-regressions.test.mjs']:
    assert expected[name]['sha256'] == r2files[name]['sha256']
    unchanged.append(name)
for name in ['M1_Independent_Contract_Tests.test.mjs', 'M1_Independent_Tester_Review_R2.md', 'M1_Independent_Tester_Evidence_R2.zip']:
    assert (TARGET / 'independent' / name).read_bytes() == (ROOT / 'outputs' / name).read_bytes()
provenance = (HANDOFF / 'HANDOFF_PROVENANCE.txt').read_text(encoding='utf-8-sig')
assert identity['sha256'] in provenance
result = {'result': 'PASS', 'archive': str(archive), 'archive_bytes': archive.stat().st_size, 'archive_sha256': identity['sha256'],
    'identity': str(identity_file), 'identity_sha256': sha(identity_file.read_bytes()), 'members': len(expected),
    'source_revision': identity['sourceRevision'], 'source_digest': identity['sourceDigest'], 'content_revision': identity['contentRevision'],
    'package_ref': identity['packageRef'], 'loose_matches': loose, 'r2_core_and_tests_unchanged': unchanged,
    'original_independent_tests_review_evidence_unchanged': True, 'extracted_to': str(TARGET)}
(EVIDENCE / 'checkpoint-verification.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result, indent=2))
