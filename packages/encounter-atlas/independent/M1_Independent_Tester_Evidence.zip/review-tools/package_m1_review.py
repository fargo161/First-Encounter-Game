import hashlib
import json
from pathlib import Path
import re
import zipfile

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'outputs'
WORK = ROOT / 'work/m1-review'
SOURCE = Path(r'C:\Users\mcdon\Documents\Codex\2026-10-17\execute-encounter-codex-lead-builder-m0\outputs')
report = OUT / 'M1_Independent_Tester_Review.md'
tests = OUT / 'M1_Independent_Contract_Tests.test.mjs'
text = report.read_text(encoding='utf-8')
expected_sections = ['Checkpoint reviewed', 'Files inspected', 'Commands actually executed', 'M0 findings', 'M1 contract findings', 'Passed checks', 'Defects', 'Questions/conflicts requiring owner or lead action', 'Verdict']
assert re.findall(r'^## \d+\. (.+)$', text, re.M) == expected_sections
assert text.count('**NOT READY FOR M2**') >= 1
tap = (WORK / 'evidence/independent-contract-tests.tap').read_text(encoding='utf-8')
assert '# tests 22' in tap and '# pass 20' in tap and '# fail 2' in tap
assert len(re.findall(r'^not ok \d+', tap, re.M)) == 2
test_lines = tests.read_text().splitlines()
assert "test('D01-A:" in test_lines[249] and "test('D01-B:" in test_lines[258]

verified = json.loads((WORK / 'evidence/checkpoint-verification.json').read_text())
prompt = Path(verified['tester_prompt']['path'])
assert hashlib.sha256(prompt.read_bytes()).hexdigest() == verified['tester_prompt']['sha256']
for original in verified['preserved_originals']:
    assert hashlib.sha256(Path(original['path']).read_bytes()).hexdigest() == original['sha256']

inputs = {
    prompt.name: prompt,
    'Encounter_M0_M1_Checkpoint.zip': SOURCE / 'Encounter_M0_M1_Checkpoint.zip',
    'Encounter_M0_M1_Checkpoint.identity.json': SOURCE / 'Encounter_M0_M1_Checkpoint.identity.json',
}
for relative in [
    'reference/Encounter_System_Master_v2.1.md',
    'reference/Encounter_Approval_Record_2026-10-17.md',
    'reference/Encounter_Core.html',
    'M0_Baseline_Inventory_and_Reuse_Plan.md',
    'M1_M2_Contract_Note.md',
    'Test_Results_and_Scope.md',
]:
    file = SOURCE / 'Encounter_M0_M1' / relative
    inputs[file.name] = file
assert len(inputs) == 9
items = [(report.name, report), (tests.name, tests)]
items += [('inputs/' + name, file) for name, file in inputs.items()]
items += [('evidence/' + file.name, file) for file in sorted((WORK / 'evidence').iterdir()) if file.is_file()]
items += [('review-tools/' + name, ROOT / 'work' / name) for name in ['verify_m1_checkpoint.py', 'run_m1_checks.py', 'record_m1_regressions.py', 'package_m1_review.py']]
manifest = [{'path': name, 'bytes': file.stat().st_size, 'sha256': hashlib.sha256(file.read_bytes()).hexdigest()} for name, file in items]
archive = OUT / 'M1_Independent_Tester_Evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for name, file in items:
        z.write(file, name)
    z.writestr('review-manifest.json', json.dumps({'checkpoint_sha256': verified['archive_sha256'], 'verdict': 'NOT READY FOR M2', 'members': manifest}, indent=2))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.namelist()) == len(manifest) + 1
    for entry in manifest:
        assert hashlib.sha256(z.read(entry['path'])).hexdigest() == entry['sha256']
print(json.dumps({'report': str(report), 'report_bytes': report.stat().st_size, 'evidence': str(archive), 'evidence_bytes': archive.stat().st_size, 'verified_bundle_members': len(manifest) + 1, 'input_files': len(inputs), 'qa': 'PASS'}, indent=2))
