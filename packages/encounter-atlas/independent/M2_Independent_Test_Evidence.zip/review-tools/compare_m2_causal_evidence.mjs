import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL, fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const work=path.join(root,'work/m2-independent-review'),checkpoint=path.join(work,'checkpoint'),evidence=path.join(work,'evidence');
const load=name=>import(pathToFileURL(path.join(checkpoint,'src',name)).href);
const E=await load('encounter.mjs'),P=await load('package.mjs'),C=await load('contracts.mjs');
const read=async name=>JSON.parse(await fs.readFile(name,'utf8'));
const pkg=await P.sealPackage(await read(path.join(checkpoint,'content/last-collection.json')));
const save=await read(path.join(evidence,'Independent_M2_Browser_Run.json'));
const run=await E.importRun(save,pkg);
const actualTrace=await read(path.join(evidence,'Independent_M2_Browser_Inspector.json'));
assert.deepEqual(E.inspectRun(run,pkg),actualTrace);
const supplied=await read(path.join(checkpoint,'M2_Interaction_Run.json'));
const suppliedRun=await E.importRun(supplied,pkg);
const suppliedTrace=await read(path.join(checkpoint,'M2_Inspector_Trace.json'));
assert.deepEqual(E.inspectRun(suppliedRun,pkg),suppliedTrace.trace);
const normalize=run=>{
  const map=new Map(run.journal.map((j,i)=>[j.command.id,`command_${(i+1).toString(16).padStart(4,'0')}`]));
  const visit=x=>typeof x==='string'?(map.get(x)??x):Array.isArray(x)?x.map(visit):x&&typeof x==='object'?Object.fromEntries(Object.entries(x).map(([k,v])=>[k,visit(v)])):x;
  return visit(run);
};
assert.deepEqual(normalize(run),normalize(suppliedRun));
const transcript=await fs.readFile(path.join(checkpoint,'M2_Interaction_Transcript.md'),'utf8');
assert.equal(run.journal.length,3);
const sections=transcript.match(/^## Commit \d+: .+$/gm);
assert.deepEqual(sections,['## Commit 1: send_message','## Commit 2: perform_action','## Commit 3: send_message']);
for(const entry of suppliedRun.journal){
  assert.ok(transcript.includes(entry.command.id));
  if(entry.command.kind==='send_message')assert.ok(transcript.includes(entry.command.payload.preview.text));
}
const b=pkg.content.bindings;
assert.equal(run.data.observations.filter(o=>o.observerId===b.ownerId).length,0);
const messages=run.data.messages;
for(const entry of run.journal.filter(j=>j.command.kind==='send_message')){
  const msg=messages.find(m=>m.id===entry.command.payload.preview.message.id);
  assert.deepEqual(msg,entry.command.payload.preview.message);
}
const disclosureChecks=[];
for(const decision of actualTrace.decisions){
  const input=decision.actualListenerInput;
  assert.deepEqual(input.observations.map(o=>o.id),decision.inputObservationIds);
  assert.ok(!JSON.stringify(input).includes(pkg.content.initial.protectedContact));
  assert.ok(!JSON.stringify(input).includes('privateComposition'));
  disclosureChecks.push({decisionId:decision.id,messageId:decision.messageId,selected:decision.selected,observationIds:decision.inputObservationIds});
}
const lines=['# Independent M2 browser interaction transcript','',
  'Freshly exercised through the supplied browser UI. The saved run replays exactly and its inspector export matches the recorded state.',
  '',`Checkpoint SHA-256: \`940a0bfaed6e45861d425a899afcb29cd518f25a25ed2d877b5c1524a1421bd7\`.`,
  `Code: M2-runtime-v1. Content: M2-paperwork-v1. Package digest: \`${pkg.ref.digest}\`.`,
  `Run: \`${run.id}\`, final revision ${run.revision}.`,''];
let replay=await E.startEncounter(pkg,{runId:run.id,noPressure:run.data.opportunities.noPressure});
const block=x=>'```text\n'+x+'\n```';
for(const entry of run.journal){
  const cmd=entry.command;
  lines.push(`## Commit ${entry.receipt.committedRevision}: ${cmd.kind}`,'',`Command: \`${cmd.id}\`. Expected revision: ${cmd.expectedRevision}.`,'');
  if(cmd.kind==='send_message')lines.push('Exact preview:',block(cmd.payload.preview.text),'');
  const result=E.dispatch(replay,pkg,cmd);assert.equal(result.status,'committed');replay=result.run;
  if(cmd.kind==='send_message'){
    const episode=E.renderEpisode(replay,entry.receipt.result.episodeId),decision=actualTrace.decisions.find(d=>d.id===entry.receipt.result.decisionId);
    lines.push('Intake:',block(episode.intake.description),'','Delivery:',block(episode.delivery.description+'\n'+episode.delivery.text),'',
      `Decision: \`${decision.id}\` selected \`${decision.selected}\`. Legitimate input observations: ${decision.inputObservationIds.join(', ')}.`,
      `Performed inspections so far: ${replay.data.actionResults.length}. Received claims so far: ${replay.data.claims.length}.`,'');
  }else{
    const physical=replay.data.actionResults.at(-1);
    for(const recipient of physical.observerDetails)lines.push(`Received by \`${recipient.observerId}\`:`,block(JSON.stringify(recipient.details,null,2)),'');
  }
  lines.push('Committed changes:',block(JSON.stringify(entry.receipt.result.changes,null,2)),'');
}
assert.deepEqual(replay,run);
lines.push('## Causal comparison','',
  'The supplied transcript regenerates byte for byte from its supplied browser run and inspector. This fresh independent browser run has identical complete state after normalizing only neutral command IDs. No semantic content, observation, decision, claim, result or material state required normalization.',
  '',`Final counts: ${run.data.messages.length} messages, ${run.data.observations.length} observations, ${run.data.actionResults.length} inspection, ${run.data.claims.length} claim, ${run.data.decisions.length} decisions.`,
  `Material state: \`${JSON.stringify(actualTrace.materialState)}\`.`,
  'Protected contact content is absent from player observations and actual listener inputs. Permission alone produced no inspection; conduct alone produced no firsthand printed detail for the clerk. The later report is a hearing observation and claim.',
  'M2 ends with an offer of verification. No recovery or collection closure was executed.','');
await fs.writeFile(path.join(root,'outputs/M2_Independent_Interaction_Transcript.md'),lines.join('\n'));
const result={result:'PASS',supplied_trace_matches_replayed_supplied_run:true,supplied_transcript_regenerates_byte_identically:true,
  fresh_browser_trace_matches_fresh_run:true,fresh_browser_run_equals_supplied_run_after_neutral_command_id_normalization:true,
  normalized_fields:'Command IDs only, consistently at every reference',browser_run_sha256:createHash('sha256').update(await fs.readFile(path.join(evidence,'Independent_M2_Browser_Run.json'))).digest('hex'),
  browser_trace_sha256:createHash('sha256').update(await fs.readFile(path.join(evidence,'Independent_M2_Browser_Inspector.json'))).digest('hex'),decisions:disclosureChecks};
await fs.writeFile(path.join(evidence,'causal-comparison.json'),JSON.stringify(result,null,2));
console.log(JSON.stringify(result,null,2));
