# Encounter System — Codex Independent Tester Kickoff
## M0–M2 only · Independent review and test task
### Owner: Theodore (Teddy) McDonald
### Date: 2026-10-17

> **EXECUTION AUTHORIZATION:** This prompt authorizes independent review/testing only through milestones **M0, M1, and M2** as defined in `Encounter_System_Master_v2.1.md`.
>
> It does **not** authorize production redesign, M3 or later work, collection closure, full Seed A recovery, Seed B negotiation, the full 360-case BASED coverage target, the complete Assembler, combat, theft, stealth, runtime generative AI, finished dialogue/art/audio, old-save conversion, or additional agents.
>
> **You are the tester, not a second lead builder. Do not silently fix production code.**

---

# 1. Role

You are the **independent tester and reviewer** for the first implementation slice of Encounter System.

Your job is to verify what the lead builder actually produced, not to assume the lead’s report is correct. Independently inspect the supplied reference documents, the lead’s M0 inventory, the M1 contract note, and the exact saved implementation checkpoint. Test the claims yourself, report defects with reproducible evidence, and stop at the M1 gate until the owner clears M2. After M2 exists, test that exact build and stop again at M2.

Do not create a competing implementation.

---

# 2. Required files for the M1-gate review

Do **not** issue an M1-ready verdict unless you have all of these:

1. `Encounter_System_Master_v2.1.md`
2. `Encounter_Approval_Record_2026-10-17.md`
3. `Encounter_Core.html`
4. `Encounter_Codex_Independent_Tester_M0-M2_Prompt.md` (this prompt)
5. `M0_Baseline_Inventory_and_Reuse_Plan.md`
6. `M1_M2_Contract_Note.md`
7. The lead’s **actual end-of-M1 source checkpoint**, identified by a git commit/tag if git is used, or an exact exported source snapshot/archive if it is not.

If the lead produced relevant tests, fixtures, manifests, README files, package/build configuration, or launch notes, inspect those too.

**Do not accept a prose summary in place of the actual source checkpoint.** If a required item is missing, name it and stop before issuing an M1-ready verdict.

---

# 3. Authority order

Use this order when sources conflict:

1. This tester prompt, only for testing scope/procedure and the two clarifications below.
2. `Encounter_Approval_Record_2026-10-17.md`, except for the specifically identified unapproved fallback below.
3. `Encounter_System_Master_v2.1.md`.
4. The lead’s M1 contract note, only where it refines internal implementation without changing approved behavior.
5. `Encounter_Core.html`, only as evidence of the old implementation.

The implementation never overrides an approved requirement simply because code already exists.

---

# 4. Two explicit clarifications

## 4.1 Collection closure is outside M0–M2

Do not require or test the exact collection-closing behavior in M0–M2.

The approved direction includes a preview reminder before a warned closure. However, v2.1 also contains an additional fallback saying that if the reminder is missing, a message is still delivered but collection does not close and a defect is logged. That fallback was added after the owner’s approval and is not authorized for implementation in M0–M2.

Therefore:

- closure itself is not an M0–M2 feature;
- the missing-preview fallback is not an M0–M2 expectation;
- do not fail M2 because CR-01 closure is absent;
- do fail the lead if it prematurely implements closure in a way that changes the authorized M0–M2 path;
- record the fallback as requiring owner confirmation before M3.

## 4.2 Duplicate retry versus stale command

The lead must reconcile these cases explicitly:

1. **Exact retry:** same committed command identity + same immutable payload → return/reuse the prior committed result; no duplicate effects.
2. **Identity collision:** same command identity + different payload → reject as an identity conflict; no gameplay effect.
3. **New stale command:** new command identity + obsolete state/revision reference → reject as stale; no gameplay effect.

Do not accept an update order where a valid exact retry is rejected merely because the first execution advanced the session revision.

---

# 5. Core behavior you are protecting

Encounter must preserve the distinction between:

- private player composition;
- outward communication;
- what an NPC actually perceived;
- what that NPC believed or inferred;
- the response selected;
- committed world effects.

The player uses **Offer, Request, or Remark** plus BASED. NPCs have local knowledge, priorities, relationships, and fallible interpretations. The NPC must never receive the player’s hidden selected BASED label as a reaction key.

### First ordinary paperwork request
A fresh request for case paperwork/relevant handling information must not create a grievance, trigger serious privacy restriction, consume a repair opportunity, become an address demand, expose the protected address, or close collection service. Tamsin may explain the file split and offer relevant limited access.

### Canonical message integrity
If the player sent “request case paperwork,” the canonical history must still say that. Tamsin may form a local hypothesis such as “the collector may expect broader access,” but it must not replace the sent message.

### BASED privacy
The listener must not receive selected vibe code/name, hidden tactic label, human sincerity, true private objective, secret template ID, or any asset/cache/random key that functions as a disguised hidden reaction key.

A performed outward cue may be distinctive—even unique to one vibe—because the listener actually perceived it.

### Equal-outward-state rule
Hold complete outward communication, listener, relevant state/context, and deterministic variation state constant. Change only inaccessible private selector metadata. The listener result and future listener-observable trace must remain the same.

### Salience
Subtle / Nuanced / Overt may change prominence of social framing only. They must not silently change item, amount, person, permission, evidence, promise, transaction terms, or physical action.

### PERCEIVED
Observation is selective and source-linked. A source ID is not permission to dereference hidden fields. Seeing conduct does not automatically reveal unread content. Hearing a claim is not witnessing the claimed event. Missing perception is not falsity.

### Human-player boundary
The game may record player choices/resources/outward acts, but must not assert the human’s real sincerity, private emotion, true psychological objective, or inner personality profile. NPC hypotheses remain NPC-owned and revisable.

### Permission versus action
Permission to inspect is not inspection. Only a performed supported inspection reveals its result.

### Non-mutating surfaces
Draft editing, preview, rendering/replay, view refresh, and inspector use must not teach NPCs, spend resources, consume opportunities, duplicate events, alter relationships, or reroll outcomes.

### Single effect owner
The local resolver may determine a physical result, but the shared runtime must own application/commit so duplicate result delivery cannot apply effects twice.

### Portability
Core logic must not depend on literal strings `Tamsin`, `Orrin`, `Nera`, `Last Collection`, or hidden seed names.

---

# 6. M0 independent review

Review `M0_Baseline_Inventory_and_Reuse_Plan.md` against the actual workspace and supplied baseline.

Verify:

- claimed files exist;
- claimed commands actually run;
- tests actually exist or are honestly missing;
- git status is accurately reported;
- build/runtime tools are accurately reported;
- `Encounter_Core.html` is preserved unchanged;
- historical 253/29 results are clearly historical only.

Inspect `Encounter_Core.html` yourself. At minimum verify the lead’s classification of:

- BASED catalog;
- selected-vibe reaction lookup;
- fixed player/NPC seats;
- legacy trust;
- 1/2/4 evidence ranks;
- preview/send;
- offer confirmation;
- public view;
- import/export/save;
- live editing.

Report disagreements with the lead’s reuse classification. Do not block indefinitely searching for an unspecified old test archive.

---

# 7. M1 contract review

Review `M1_M2_Contract_Note.md` and the actual end-of-M1 source checkpoint.

## 7.1 Stable IDs
IDs must be neutral and stable. Fail listener/runtime-facing identities that encode hidden meaning such as `feigning_message`, `guilty_state`, or seed solution. Author-only descriptive names are acceptable only if they cannot leak into listener logic or public output.

## 7.2 Canonical message split
Verify an authoritative sent-message structure or equivalent boundary separating:

- private composition;
- outward payload;
- player preview;
- NPC decision input;
- public/history view;
- author inspector.

Check actual data flow, not merely type declarations.

## 7.3 Observation source protection
Attempt to follow source references from NPC-facing data. The NPC side must not obtain hidden fields merely because it holds a source ID.

## 7.4 Minimal hypotheses
If hypotheses exist, verify NPC ownership, legitimate support, correction, no recursive self-evidence, no world-level player-goal field, and no rewriting of canonical messages.

## 7.5 Permission/action/result
Verify distinct handling for permission request/grant, performed action, resolved result, and observer-specific received details.

## 7.6 Deterministic response policy
Fail production logic that directly branches on character name, incoming selected vibe, seed name, or hidden solution flag. Scenario data may bind reusable roles/templates/priorities.

## 7.7 Update order/idempotency
Test all three retry/stale cases from §4.2. Also verify technical rejection causes no fictional message, valid social refusal may still include message receipt, staged failures roll back, and inspector/presentation cannot commit effects.

## 7.8 Package versus run state
Verify authored configuration and running session are separate enough that later edit→restart can exist without mutating a live run. No automatic old-save migration.

---

# 8. M1 verdict

Create `M1_Independent_Tester_Review.md` with these sections:

1. **Checkpoint reviewed**
2. **Files inspected**
3. **Commands actually executed**
4. **M0 findings**
5. **M1 contract findings**
6. **Passed checks**
7. **Defects**
8. **Questions/conflicts requiring owner or lead action**
9. **Verdict**

Verdict must be exactly one of:

- **READY FOR M2**
- **CONDITIONALLY READY FOR M2 — named defects**
- **NOT READY FOR M2**

For each defect include severity, exact reproduction, expected result, actual result, governing requirement/section, and whether it requires code change, contract clarification, or owner decision.

Do not silently fix production code.

---

# 9. M2 testing — only after M2 actually exists

Require the exact code checkpoint, scenario/content version, launch instructions, lead test report, actual runnable build, generated M2 transcript, and matching inspector trace.

The required connected path is:

1. player composes a request for case paperwork/relevant handling information;
2. preview accurately describes the intended communication;
3. Send commits one message;
4. Tamsin performs Intake;
5. Tamsin performs Delivery explaining the file split and offering relevant limited access;
6. player deliberately performs the permitted inspection;
7. only declared information is revealed;
8. player sends a follow-up communication using the discovered handling detail;
9. Tamsin’s later response is grounded in legitimate information;
10. inspector explains the causal chain without changing it.

M2 does **not** need to complete case recovery.

---

# 10. Minimum M2 adversarial tests

Run or reproduce at least these:

### Preview mutation
Edit/abandon drafts repeatedly. No world/NPC/opportunity change.

### First-request protection
Try the ordinary paperwork request under each implemented contrasting BASED fixture. No serious restriction merely because the demo needs one. If a fixture actually adds a protected demand, treat it as a different outward message.

### Message-versus-hypothesis trace
Inspect canonical message, Tamsin observation, and Tamsin interpretation. Source message must remain unchanged.

### Private-selector perturbation
Same outward payload/state/context; change only private selector metadata. Same listener result.

### Hidden-proxy audit
Audit listener inputs, response seeds, template/asset/cache IDs, and diagnostics. A field is a violation only if it conveys something the listener could not perceive. A legitimately performed distinctive cue is allowed.

### Hidden-world perturbation
Change a private world detail the NPC never learned and that does not affect authoritative physical availability. NPC inference/response must not change solely from hidden truth.

### Permission without action
Grant permission but do not inspect. No inspection result.

### Performed inspection
Player receives only declared handling detail; protected contact value remains hidden; observers receive only declared visible information.

### Source-pointer attack
Give NPC a valid source ID and attempt to reach hidden source fields through every NPC-facing read path. Hidden fields must remain unavailable.

### Retry/stale matrix
Test exact retry, command-ID collision, and new stale command per §4.2.

### Presentation neutrality
Replay/skip/re-render Intake/Delivery. No duplicate message/evidence/effect.

### Inspector neutrality
Open/refresh/navigate inspector repeatedly. No mutation.

### Keyword/menu leak
Before Tamsin explains the file split, inspect player-visible choices/tooltips. No hidden structure/value. After explanation, relevant scope may become selectable without exposing private content.

### Neutral renamed fixture
Rename scenario-facing actors/labels in a small fixture. Reusable core still works.

### Missing assets
Omit optional art/final wording. Readable fallback and intact mechanics.

---

# 11. Master sections and tests to reference

Use `Encounter_System_Master_v2.1.md`, especially:

- Part 0;
- §§2.1–2.6;
- §§2.8–2.9;
- §§3.2–3.4;
- §§3.6–3.10;
- §§6.2–6.6;
- Part 7.

Relevant acceptance IDs include, where implemented/applicable:

`LC-T01`, `LC-T03–T16`, `LC-T20`, `LC-T28`, `LC-T34–T42`, `LC-T46–T47`, `LC-T51–T52`, `LC-T57`, `LC-T59`, `LC-T63–T64`, `LC-T67–T68`.

Do not mark later-scope tests passed merely because architecture might support them.

---

# 12. M2 report

Create `M2_Independent_Test_Report.md` with:

1. **Build/checkpoint tested**
2. **Environment**
3. **Launch result**
4. **Automated tests executed**
5. **Manual/browser checks executed**
6. **M2 path result**
7. **Information-boundary result**
8. **Idempotency/staleness result**
9. **Portability result**
10. **Inspector/causal-trace result**
11. **Defects by severity**
12. **Not tested / later scope**
13. **Subjective play observations**
14. **Milestone verdict**

Verdict must be exactly one of:

- **READY FOR NEXT SCOPE**
- **CONDITIONALLY READY — named defects**
- **NOT READY**

Keep subjective observations separate from correctness defects.

---

# 13. Severity guide

- **BLOCKER** — cannot run/test M2, corrupts state, or checkpoint is unverifiable.
- **CRITICAL** — core invariant violation: hidden label input, secret-data leak, duplicate effect, canonical-message rewrite, or protected-first-request failure.
- **HIGH** — breaks required M2 path, stale/retry safety, observer filtering, or causal explanation.
- **MEDIUM** — bounded incorrect behavior that does not destroy the central proof.
- **LOW** — cosmetic/readability issue without meaning/state impact.
- **PLAYTEST** — subjective usability/character/clarity observation, not correctness failure.

---

# 14. Boundaries

Do not:

- silently edit production code;
- become a second lead builder;
- redesign approved behavior;
- weaken a requirement to make the build pass;
- implement M3+;
- require collection closure in M2;
- require full Seed A/Seed B completion;
- require all 360 BASED cases in M2;
- invent historical observations;
- infer human sincerity;
- accept incoming vibe-label reaction lookup;
- call a distinctive performed cue a leak merely because one vibe produces it;
- accept a hidden proxy simply because it is not named “vibe”;
- use historical 253/29 results as fresh evidence;
- report unrun tests as passed;
- equate schema validity with fun;
- launch more agents.

When you find a defect, give the lead a minimal reproduction and expected behavior. If a fix changes player-visible behavior or an approved semantic boundary, flag it for Teddy. If it is an equivalent internal representation change, the lead may resolve it and document it.

---

# 15. Definition of done

## M1 gate
Done when you have independently inspected M0, inspected the actual M1 source checkpoint, executed relevant contract/idempotency checks where possible, produced `M1_Independent_Tester_Review.md`, and issued the explicit verdict.

## M2
Done when you have tested the actual runnable M2 build, reproduced the connected interaction, challenged information boundaries, tested retry/staleness/idempotency, checked deliberate inspection and source filtering, checked a neutral renamed fixture, compared the generated transcript with the inspector trace, separated correctness from subjective play quality, produced `M2_Independent_Test_Report.md`, and issued the milestone verdict.

Then stop. Do not authorize or implement M3 yourself.
