import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent.parent
CHECKPOINT = ROOT / 'work/m1-review/checkpoint'
EVIDENCE = ROOT / 'work/m1-review/evidence'
commands_path = EVIDENCE / 'commands.json'
commands = json.loads(commands_path.read_text())
env = dict(os.environ)
env['ENCOUNTER_CHECKPOINT'] = str(CHECKPOINT)
argv = [shutil.which('node'), '--test', '--test-name-pattern=D01-', '--test-reporter=tap', str(ROOT / 'outputs/M1_Independent_Contract_Tests.test.mjs')]
result = subprocess.run(argv, cwd=ROOT, env=env, capture_output=True, text=True, encoding='utf-8', errors='replace')
log = f'CWD: {ROOT}\nENCOUNTER_CHECKPOINT: {CHECKPOINT}\nCOMMAND: {subprocess.list2cmdline(argv)}\nEXIT: {result.returncode}\n\nSTDOUT:\n{result.stdout}\nSTDERR:\n{result.stderr}'
(EVIDENCE / 'focused-defect-reproductions.txt').write_text(log, encoding='utf-8')
commands['commands'].append({'label': 'focused-defect-reproductions', 'cwd': str(ROOT), 'env': {'ENCOUNTER_CHECKPOINT': str(CHECKPOINT)}, 'argv': argv, 'exit': result.returncode})
commands['commands'].append({'label': 'independent-contract-tests-full', 'cwd': str(ROOT), 'shell': 'PowerShell', 'command': "$env:ENCOUNTER_CHECKPOINT = '" + str(CHECKPOINT) + "'; node --test --test-reporter=tap outputs\\M1_Independent_Contract_Tests.test.mjs *> work\\m1-review\\evidence\\independent-contract-tests.tap", 'result_from_tap': {'tests': 22, 'pass': 20, 'fail': 2}, 'note': 'Initial shell command displayed the log afterward; its final shell exit is not the node exit. Focused rerun captures child exit directly.'})
commands_path.write_text(json.dumps(commands, indent=2), encoding='utf-8')
assert result.returncode == 1 and '# fail 2' in result.stdout
print('Focused regressions: 2 reproduced; node exit 1.')

source = Path(r'C:\Users\mcdon\Documents\Codex\2026-10-17\execute-encounter-codex-lead-builder-m0\outputs')
identity = json.loads((source / 'Encounter_M0_M1_Checkpoint.identity.json').read_text())
verified = []
for entry in identity['files']:
    extracted = CHECKPOINT / entry['path']
    supplied = source / 'Encounter_M0_M1' / entry['path']
    for file in (extracted, supplied):
        assert file.stat().st_size == entry['bytes']
        assert hashlib.sha256(file.read_bytes()).hexdigest() == entry['sha256'], str(file)
    verified.append(entry['path'])
archive_hash = hashlib.sha256((source / identity['snapshot']).read_bytes()).hexdigest()
assert archive_hash == identity['sha256']
(EVIDENCE / 'final-preservation-check.json').write_text(json.dumps({'archive_sha256': archive_hash, 'result': 'PASS', 'unchanged_extracted_members': verified, 'unchanged_builder_output_members': verified}, indent=2), encoding='utf-8')
print('Final preservation: exact archive plus all 24 extracted and all 24 builder-output members unchanged.')
