import hashlib
import json
from pathlib import Path, PurePosixPath
import zipfile

HERE = Path(__file__).resolve().parent
SOURCE = Path(r'C:\Users\mcdon\Documents\Codex\2026-10-17\execute-encounter-codex-lead-builder-m0\outputs')
TARGET = HERE / 'm1-review' / 'checkpoint'
EVIDENCE = HERE / 'm1-review' / 'evidence'
EVIDENCE.mkdir(parents=True, exist_ok=True)
identity_path = SOURCE / 'Encounter_M0_M1_Checkpoint.identity.json'
archive_path = SOURCE / 'Encounter_M0_M1_Checkpoint.zip'
identity = json.loads(identity_path.read_text(encoding='utf-8-sig'))
digest = lambda b: hashlib.sha256(b).hexdigest()
archive_hash = digest(archive_path.read_bytes())
assert archive_path.name == identity['snapshot']
assert archive_hash == identity['sha256'], 'Archive hash mismatch'
expected = {x['path']: x for x in identity['files']}
assert len(expected) == len(identity['files']), 'Duplicate manifest path'
members = []
with zipfile.ZipFile(archive_path) as z:
    names = [x.filename for x in z.infolist() if not x.is_dir()]
    assert len(names) == len(set(names)), 'Duplicate ZIP member'
    assert set(names) == set(expected), 'ZIP membership does not equal manifest'
    for name in names:
        p = PurePosixPath(name)
        assert not p.is_absolute() and '..' not in p.parts and '\\' not in name and ':' not in name
        data = z.read(name)
        entry = expected[name]
        assert len(data) == entry['bytes'], name + ': size mismatch'
        assert digest(data) == entry['sha256'], name + ': hash mismatch'
        members.append({'path': name, 'bytes': len(data), 'sha256': digest(data), 'match': True})
    assert not TARGET.exists(), 'Refusing to overwrite an existing review extraction'
    z.extractall(TARGET)

separate = []
for name in [
    'reference/Encounter_System_Master_v2.1.md',
    'reference/Encounter_Approval_Record_2026-10-17.md',
    'reference/Encounter_Core.html',
    'M0_Baseline_Inventory_and_Reuse_Plan.md',
    'M1_M2_Contract_Note.md',
    'Test_Results_and_Scope.md',
]:
    candidate = SOURCE / 'Encounter_M0_M1' / name
    sha = digest(candidate.read_bytes())
    assert sha == expected[name]['sha256'], 'Separate supplied copy mismatch: ' + name
    separate.append({'path': str(candidate), 'sha256': sha, 'match': True})

originals = []
for original, member in [
    ('Encounter_Codex_Lead_Builder_M0-M2_Prompt.md', 'reference/Encounter_Codex_Lead_Builder_M0-M2_Prompt.md'),
    ('Encounter_System_Master_v2.1 (1).md', 'reference/Encounter_System_Master_v2.1.md'),
    ('Encounter_Approval_Record_2026-10-17 (1).md', 'reference/Encounter_Approval_Record_2026-10-17.md'),
    ('Encounter_Core (1).html', 'reference/Encounter_Core.html'),
]:
    candidate = Path(r'C:\Users\mcdon\Downloads') / original
    sha = digest(candidate.read_bytes())
    assert sha == expected[member]['sha256'], 'Original mismatch: ' + original
    originals.append({'path': str(candidate), 'sha256': sha, 'match': True})

prompt = Path(r'C:\Users\mcdon\Downloads\Encounter_Codex_Independent_Tester_M0-M2_Prompt.md')
result = {
    'archive': str(archive_path), 'archive_bytes': archive_path.stat().st_size,
    'archive_sha256': archive_hash, 'identity': str(identity_path),
    'identity_sha256': digest(identity_path.read_bytes()),
    'extracted_to': str(TARGET), 'verified_members': members,
    'separate_supplied_copies': separate, 'preserved_originals': originals,
    'tester_prompt': {'path': str(prompt), 'bytes': prompt.stat().st_size, 'sha256': digest(prompt.read_bytes())},
    'result': 'PASS',
}
(EVIDENCE / 'checkpoint-verification.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps({'result': 'PASS', 'archive_sha256': archive_hash, 'members': len(members), 'separate_matches': len(separate), 'preserved_original_matches': len(originals), 'extracted_to': str(TARGET)}, indent=2))
