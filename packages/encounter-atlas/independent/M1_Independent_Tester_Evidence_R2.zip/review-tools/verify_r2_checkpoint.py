import difflib
import hashlib
import json
from pathlib import Path, PurePosixPath
import zipfile

ROOT = Path(__file__).resolve().parent.parent
WORK = ROOT / 'work/r2-review'
EVIDENCE = WORK / 'evidence'
TARGET = WORK / 'checkpoint'
SOURCE = Path(r'C:\Users\mcdon\Documents\Codex\2026-10-17\execute-encounter-codex-lead-builder-m0\outputs')
EVIDENCE.mkdir(parents=True, exist_ok=True)
sha = lambda data: hashlib.sha256(data).hexdigest()

def verify_archive(archive, manifest):
    identity = json.loads(manifest.read_text(encoding='utf-8-sig'))
    assert archive.name == identity['snapshot']
    assert sha(archive.read_bytes()) == identity['sha256'], str(archive)
    entries = {entry['path']: entry for entry in identity['files']}
    assert len(entries) == len(identity['files'])
    with zipfile.ZipFile(archive) as z:
        names = z.namelist()
        assert len(names) == len(set(name.casefold() for name in names))
        assert set(names) == set(entries)
        for name in names:
            path = PurePosixPath(name)
            assert not path.is_absolute() and '..' not in path.parts and ':' not in name and '\\' not in name
            data = z.read(name)
            assert len(data) == entries[name]['bytes'] and sha(data) == entries[name]['sha256'], name
        assert z.testzip() is None
    return identity

r1zip = SOURCE / 'Encounter_M0_M1_Checkpoint.zip'
r1 = verify_archive(r1zip, SOURCE / 'Encounter_M0_M1_Checkpoint.identity.json')
r2zip = SOURCE / 'Encounter_M0_M1_Checkpoint_R2.zip'
r2manifest = SOURCE / 'Encounter_M0_M1_Checkpoint_R2.identity.json'
r2 = verify_archive(r2zip, r2manifest)
assert r1['sha256'] == 'e42900345ee3c1aba1956d6212577683321bc5c5f42ab3e1d6f12eb45fceb3bf'
assert not TARGET.exists(), 'Refusing to overwrite an existing R2 extraction'
with zipfile.ZipFile(r2zip) as z:
    z.extractall(TARGET)

oldmap = {entry['path']: entry for entry in r1['files']}
newmap = {entry['path']: entry for entry in r2['files']}
changed = sorted(name for name in oldmap.keys() & newmap.keys() if oldmap[name]['sha256'] != newmap[name]['sha256'])
added = sorted(newmap.keys() - oldmap.keys())
removed = sorted(oldmap.keys() - newmap.keys())
prod_changed = [name for name in changed if name.startswith('src/')]
assert prod_changed == ['src/action-boundary.mjs', 'src/runtime.mjs']
assert not removed
for name in ['M0_Baseline_Inventory_and_Reuse_Plan.md', 'src/contracts.mjs', 'src/views.mjs', 'tests/fixtures.mjs', 'tests/runtime.test.mjs', 'tests/views.test.mjs', 'package.json']:
    assert oldmap[name]['sha256'] == newmap[name]['sha256']
for name in oldmap:
    if name.startswith('reference/'):
        assert oldmap[name]['sha256'] == newmap[name]['sha256']

tester_files = ['M1_Independent_Contract_Tests.test.mjs', 'M1_Independent_Tester_Review.md', 'M1_Independent_Tester_Evidence.zip']
tester_records = []
for name in tester_files:
    original = ROOT / 'outputs' / name
    bundled = TARGET / 'independent' / name
    assert original.read_bytes() == bundled.read_bytes(), 'Tester evidence changed: ' + name
    tester_records.append({'name': name, 'sha256': sha(original.read_bytes()), 'bytes': original.stat().st_size, 'unchanged': True})
with zipfile.ZipFile(ROOT / 'outputs/M1_Independent_Tester_Evidence.zip') as z:
    previous = json.loads(z.read('review-manifest.json'))
    assert previous['checkpoint_sha256'] == r1['sha256']
    for entry in previous['members']:
        assert len(z.read(entry['path'])) == entry['bytes']
        assert sha(z.read(entry['path'])) == entry['sha256']
    assert z.read('M1_Independent_Contract_Tests.test.mjs') == (ROOT / 'outputs/M1_Independent_Contract_Tests.test.mjs').read_bytes()
    assert z.read('inputs/Encounter_M0_M1_Checkpoint.zip') == r1zip.read_bytes()

external_report = SOURCE / 'Encounter_M0_M1_R2/M1_Defect_Remediation_Report.md'
assert sha(external_report.read_bytes()) == newmap['M1_Defect_Remediation_Report.md']['sha256']
with zipfile.ZipFile(r1zip) as z:
    diffs = []
    for name in changed:
        if name.endswith(('.mjs', '.py', '.md')):
            diffs.extend(difflib.unified_diff(z.read(name).decode('utf-8-sig').splitlines(True), (TARGET / name).read_text(encoding='utf-8-sig').splitlines(True), fromfile='R1/' + name, tofile='R2/' + name))
(EVIDENCE / 'r1-r2.diff').write_text(''.join(diffs), encoding='utf-8')
result = {'result': 'PASS', 'r2_archive': str(r2zip), 'r2_bytes': r2zip.stat().st_size, 'r2_sha256': r2['sha256'],
    'r2_identity': str(r2manifest), 'r2_identity_sha256': sha(r2manifest.read_bytes()), 'r2_members': len(newmap),
    'r1_sha256': r1['sha256'], 'r1_members': len(oldmap), 'changed': changed, 'added': added, 'removed': removed,
    'changed_production_modules': prod_changed, 'unchanged_tester_evidence': tester_records,
    'external_remediation_report_matches_archive': True, 'extraction': str(TARGET)}
(EVIDENCE / 'checkpoint-verification.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result, indent=2))
