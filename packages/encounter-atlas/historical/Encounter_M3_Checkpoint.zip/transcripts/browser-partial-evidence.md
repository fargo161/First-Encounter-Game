# Generated M3 interaction transcript

Source run: `runs/browser-partial-evidence.json`, SHA-256 `c4476ffb82e3247b38aa8f1ca6da837aaf1ecfa972b4dc0efeaf2253f8c4cdda`.
Code: `M3-runtime-v1`, source digest `716a11c4efe9462e8ad60f16d6615ed8537811cf779d10dee424ef92558e3a94`.
Content: `M3-protective-shortcut-v1`, package digest `2ce9f61b996f17392a39c56f4005d8203b7940aa4974564fafa54d110e35ae8f`.
Generated from the actual browser Save run export after complete package, domain and command-journal validation. The text below is emitted by the implementation.

## Commit 1 · perform_action / physical

Command `command_5c4b690369ea40899483b760fccef929`, expected revision 0.

Physical result `result_0001`: performed; request action `action_0001`.

Received by `actor_0001`:
```text
{
  "authority": {
    "collectorId": "actor_0001",
    "itemId": "subject_0001",
    "ownerId": "actor_0003",
    "ticketId": "subject_0002",
    "verified": true
  },
  "conduct": "The valid collection ticket is shown and verified."
}
```

Received by `actor_0002`:
```text
{
  "authority": {
    "collectorId": "actor_0001",
    "itemId": "subject_0001",
    "ownerId": "actor_0003",
    "ticketId": "subject_0002",
    "verified": true
  },
  "conduct": "The valid collection ticket is shown and verified."
}
```

Actual effects:
```text
[]
```

Committed changes:
```text
[
  {
    "id": "result_0001",
    "outcome": "performed",
    "type": "physical_result"
  }
]
```

## Commit 2 · send_message

Command `command_a611fdc729cd4c87b0d588de5ed9b744`, expected revision 1.

Bound preview:
```text
Requests access to Collection record concerning Collection record.
Acknowledges the clerk’s work and communicates supportive concern about a defensible handover.
Social framing is emphatic.
```

Intake:
```text
Looks from the received material to the collector, holding a composed expression.
```

Delivery:
```text
Keeps the selected material in view and states the bounded response with a composed face.
The customer file contains case-handling material and unrelated private contact information. The relevant extract and permitted handling tray are available. Private contact values remain covered.
Social framing is measured.
```

Decision `decision_0001`; exact actor-local input and eligibility reasons are in the matching trace.

Committed changes:
```text
[]
```

## Commit 3 · send_message

Command `command_79d18c3f1474440cb82a670bfc450044`, expected revision 2.

Bound preview:
```text
Offers 100 minor money units for ordinary collection; no fee or debt is asserted.
Acknowledges the clerk’s work and communicates supportive concern about a defensible handover.
Social framing is emphatic.
```

Intake:
```text
Looks from the received material to the collector, holding a composed expression.
```

Delivery:
```text
Keeps the selected material in view and states the bounded response with a composed face.
No extra collection charge is due. I decline the ordinary payment offer as unnecessary. No money moves and no new debt or bribery judgment is created.
Social framing is measured.
```

Decision `decision_0002`; exact actor-local input and eligibility reasons are in the matching trace.

Committed changes:
```text
[]
```

## Commit 4 · send_message

Command `command_a67e3a0c696940d0a78bb89c0f44146b`, expected revision 3.

Bound preview:
```text
Asks where Nera’s green instrument case is. This is a request for location information, not a physical search.
Acknowledges the clerk’s work and communicates supportive concern about a defensible handover.
Social framing is emphatic.
```

Intake:
```text
Looks from the received material to the collector, holding a composed expression.
```

Delivery:
```text
Keeps the selected material in view and states the bounded response with a composed face.
I refer you to the recorded entry and the relevant inspection route rather than explaining the earlier movement.
Social framing is measured.
```

Decision `decision_0003`; exact actor-local input and eligibility reasons are in the matching trace.

Committed changes:
```text
[]
```

## Commit 5 · perform_action / physical

Command `command_156d4793028f4abe84d97a2ec2176631`, expected revision 4.

Physical result `result_0002`: performed; request action `action_0002`.

Received by `actor_0001`:
```text
{
  "conduct": "Performs the permitted inspect action.",
  "evidence": [
    {
      "form": "document",
      "label": "Recipient signature: unfilled",
      "markId": "subject_0010",
      "predicate": "recipient_signature",
      "roots": [
        {
          "id": "result_0002",
          "kind": "action_result"
        }
      ],
      "subjectId": "subject_0003",
      "value": "unfilled"
    }
  ],
  "references": [
    {
      "id": "subject_0003",
      "label": "Collection record"
    }
  ]
}
```

Received by `actor_0002`:
```text
{
  "conduct": "Sees the collector inspect the permitted extract; the small print is unreadable from here.",
  "evidence": [],
  "references": []
}
```

Actual effects:
```text
[]
```

Committed changes:
```text
[
  {
    "id": "result_0002",
    "outcome": "performed",
    "type": "physical_result"
  }
]
```

## Commit 6 · perform_action / physical

Command `command_254b61a877794389b0f58c03ae42cf50`, expected revision 5.

Physical result `result_0003`: performed; request action `action_0003`.

Received by `actor_0001`:
```text
{
  "conduct": "Performs the permitted search action.",
  "evidence": [
    {
      "form": "document",
      "label": "Drying tag 041 matches the case reference",
      "markId": "subject_0010",
      "predicate": "item_reference",
      "roots": [
        {
          "id": "result_0003",
          "kind": "action_result"
        }
      ],
      "subjectId": "subject_000c",
      "value": "subject_0001"
    },
    {
      "form": "document",
      "label": "Drying tag records internal drying, not recipient collection",
      "markId": "subject_0010",
      "predicate": "handling_type",
      "roots": [
        {
          "id": "result_0003",
          "kind": "action_result"
        }
      ],
      "subjectId": "subject_000c",
      "value": "internal_drying"
    }
  ],
  "references": [
    {
      "id": "subject_000c",
      "label": "Numbered drying tag"
    },
    {
      "id": "subject_0001",
      "label": "Nera’s green instrument case"
    }
  ]
}
```

Received by `actor_0004`:
```text
{
  "conduct": "Sees the collector search the permitted handling tray; does not read the tag.",
  "evidence": [],
  "references": []
}
```

Actual effects:
```text
[]
```

Committed changes:
```text
[
  {
    "id": "result_0003",
    "outcome": "performed",
    "type": "physical_result"
  }
]
```

## Final independent outcomes

```text
{
  "recovered": false,
  "serviceOpen": true,
  "ownerId": "actor_0003",
  "holderId": "subject_0007",
  "quantity": 1,
  "balances": {
    "actor_0001": 1200,
    "actor_0002": 0,
    "actor_0004": 0
  },
  "recordCorrected": false,
  "privateDisclosed": false
}
```
Repair/visit state: `[{"holderId":"actor_0002","repairUsed":false,"restricted":false,"restrictedOrRepaired":false,"restrictionMessageId":null,"serviceId":"service_0001","warningMessageId":null}]`.
Technical defects: 0. Canonical observations: 21.
Private contact values are absent from player knowledge and actual decision inputs. Author/package exports retain synthetic fixture truth. Recovery, spending, privacy and record correction remain distinct.
