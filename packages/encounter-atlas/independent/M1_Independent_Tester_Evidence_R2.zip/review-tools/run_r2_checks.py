import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent.parent
WORK = ROOT / 'work/r2-review'
CHECKPOINT = WORK / 'checkpoint'
EVIDENCE = WORK / 'evidence'
ORIGINAL_TESTS = ROOT / 'outputs/M1_Independent_Contract_Tests.test.mjs'
SOURCE = Path(r'C:\Users\mcdon\Documents\Codex\2026-10-17\execute-encounter-codex-lead-builder-m0\outputs')
records = []

def run(label, args, cwd=CHECKPOINT, checkpoint=None, expected_exit=0):
    env = dict(os.environ)
    if checkpoint is not None:
        env['ENCOUNTER_CHECKPOINT'] = str(checkpoint)
    args = [str(arg) for arg in args]
    result = subprocess.run(args, cwd=cwd, env=env, capture_output=True, text=True, encoding='utf-8', errors='replace')
    log = f'CWD: {cwd}\nENCOUNTER_CHECKPOINT: {env.get("ENCOUNTER_CHECKPOINT", "(unset)")}\nCOMMAND: {subprocess.list2cmdline(args)}\nEXIT: {result.returncode}\n\nSTDOUT:\n{result.stdout}\nSTDERR:\n{result.stderr}'
    (EVIDENCE / (label + '.txt')).write_text(log, encoding='utf-8')
    counts = {key: int(value) for key, value in re.findall(r'^# (tests|pass|fail|skipped|cancelled|todo) (\d+)$', result.stdout, re.M)}
    record = {'label': label, 'cwd': str(cwd), 'argv': args, 'exit': result.returncode, 'expected_exit': expected_exit, 'counts': counts}
    if checkpoint is not None:
        record['env'] = {'ENCOUNTER_CHECKPOINT': str(checkpoint)}
    records.append(record)
    print(f'{label}: exit {result.returncode}; {counts}', flush=True)
    assert result.returncode == expected_exit, label
    return result

node = shutil.which('node')
npm = shutil.which('npm.cmd')
assert node and npm
run('node-version', [node, '--version'])
run('npm-version', [npm, '--version'])
run('python-version', [sys.executable, '--version'])

# Reproduce using a fresh R1 extraction, not the lead's archived execution logs.
import zipfile
r1 = WORK / 'r1-control'
assert not r1.exists()
with zipfile.ZipFile(SOURCE / 'Encounter_M0_M1_Checkpoint.zip') as z:
    z.extractall(r1)
run('r1-original-defects', [node, '--test', '--test-name-pattern=D01-', '--test-reporter=tap', ORIGINAL_TESTS], checkpoint=r1, expected_exit=1)
run('r2-original-defects', [node, '--test', '--test-name-pattern=D01-', '--test-reporter=tap', ORIGINAL_TESTS], checkpoint=CHECKPOINT)
run('r2-baseline-audit', [node, 'scripts/audit-baseline.cjs'])
run('r2-builder-contract-tests', [npm, 'test', '--', '--test-reporter=tap'])
run('r2-unchanged-independent-suite', [node, '--test', '--test-reporter=tap', ORIGINAL_TESTS], checkpoint=CHECKPOINT)
run('r2-builder-archive-verifier', [sys.executable, 'scripts/verify-checkpoint.py', SOURCE / 'Encounter_M0_M1_Checkpoint_R2.identity.json'])

# Independently recompute the executable-source digest without rewriting the extraction.
paths = [CHECKPOINT / 'package.json']
for folder in ('src', 'tests', 'scripts'):
    paths.extend(p for p in (CHECKPOINT / folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
entries = [{'path': p.relative_to(CHECKPOINT).as_posix(), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(paths)]
digest = hashlib.sha256(json.dumps(entries, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
stored = json.loads((CHECKPOINT / 'evidence/M1_source_identity.json').read_text())
assert entries == stored['files'] and digest == stored['sourceDigest']
assert stored['sourceRevision'] == 'M1-contract-v2'
(EVIDENCE / 'independent-source-digest.json').write_text(json.dumps({'sourceRevision': stored['sourceRevision'], 'sourceDigest': digest, 'files': entries, 'matches_stored': True}, indent=2), encoding='utf-8')
print('Independent source digest: PASS ' + digest, flush=True)

# Verify the changed packaging scripts only in a disposable copy.
tooling = WORK / 'tooling-replay'
assert not tooling.exists()
shutil.copytree(CHECKPOINT, tooling)
run('r2-source-identity-regenerated', [sys.executable, 'scripts/source-identity.py'], cwd=tooling)
run('r2-snapshot-regenerated', [sys.executable, 'scripts/snapshot.py', 'Encounter_M0_M1_Checkpoint_R2'], cwd=tooling)
rebuilt = WORK / 'Encounter_M0_M1_Checkpoint_R2.zip'
expected = json.loads((SOURCE / 'Encounter_M0_M1_Checkpoint_R2.identity.json').read_text())
assert hashlib.sha256(rebuilt.read_bytes()).hexdigest() == expected['sha256']
before = hashlib.sha256(rebuilt.read_bytes()).hexdigest()
run('r2-snapshot-overwrite-refused', [sys.executable, 'scripts/snapshot.py', 'Encounter_M0_M1_Checkpoint_R2'], cwd=tooling, expected_exit=1)
assert hashlib.sha256(rebuilt.read_bytes()).hexdigest() == before
run('r2-old-snapshot-name-refused', [sys.executable, 'scripts/snapshot.py', 'Encounter_M0_M1_Checkpoint'], cwd=tooling, expected_exit=1)
print('Regenerated archive byte identity and non-overwrite guard: PASS', flush=True)
(EVIDENCE / 'commands.json').write_text(json.dumps({'time_utc': datetime.now(timezone.utc).isoformat(), 'commands': records}, indent=2), encoding='utf-8')
