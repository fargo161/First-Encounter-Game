import hashlib
import json
from pathlib import Path
import re
import shutil
import zipfile

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'outputs'
WORK = ROOT / 'work/m2-independent-review'
EVIDENCE = WORK / 'evidence'
HANDOFF = Path(r'C:\Users\mcdon\Downloads\Encounter_M2_Tester_Handoff')
sha = lambda b: hashlib.sha256(b).hexdigest()
identity = json.loads((HANDOFF / 'Encounter_M2_Checkpoint.identity.json').read_text(encoding='utf-8-sig'))
initial = json.loads((EVIDENCE / 'checkpoint-verification.json').read_text(encoding='utf-8'))
assert sha((HANDOFF / identity['snapshot']).read_bytes()) == initial['archive_sha256'] == identity['sha256']
assert sha((HANDOFF / 'Encounter_M2_Checkpoint.identity.json').read_bytes()) == initial['identity_sha256']
for entry in identity['files']:
    data = (WORK / 'checkpoint' / entry['path']).read_bytes()
    assert len(data) == entry['bytes'] and sha(data) == entry['sha256'], entry['path']
for entry in initial['loose_matches']:
    assert sha((HANDOFF / entry['name']).read_bytes()) == entry['sha256']
for name in ['M1_Independent_Contract_Tests.test.mjs','M1_Independent_Tester_Review_R2.md','M1_Independent_Tester_Evidence_R2.zip']:
    assert (OUT / name).read_bytes() == (WORK / 'checkpoint/independent' / name).read_bytes()
assert sha((OUT / 'M2_Independent_Contract_Tests.test.mjs').read_bytes()) == '858171387e7edbcfe105a39cfe3d1a6f1dd58bf505a5dc65dbbd83df24ccc0de'
(EVIDENCE / 'final-preservation-check.json').write_text(json.dumps({'result':'PASS','archive_sha256':identity['sha256'],'manifest_sha256':initial['identity_sha256'],'unchanged_review_members':len(identity['files']),'loose_handoff_documents_unchanged':True,'original_m1_independent_inputs_unchanged':True,'independent_m2_test_unchanged':True},indent=2),encoding='utf-8')

launch = {'supplied_build_sha256':next(f['sha256'] for f in identity['files'] if f['path']=='dist/index.html'),
 'initial_readme_server_attempts':{'command':'python -u scripts/serve.py','port':8765,'result':'Terminal-managed listeners printed a URL but browser/HTTP requests timed out; restricted socket access was also observed.'},
 'network_permission':{'enabled':True,'scope':'turn','granted':True},
 'managed_fresh_port_attempt':{'port':58526,'result':'Browser and HTTP requests timed out.'},
 'successful_launch':{'server':'review-tools/m2_preview_server.py','transport':'Python standard-library ThreadingHTTPServer, loopback only','url':'http://127.0.0.1:62586/','pid':1568,'mode':'Start-Process -WindowStyle Hidden, detached','served_directory':str(WORK/'checkpoint/dist'),'result':'Browser loaded and completed M2.'},
 'screenshot_note':'Initial capture while the browser was hidden failed; visible-browser JPEG captures succeeded.',
 'cleanup':{'detached_pid_1568':'Command line matched the task server before Stop-Process; stopped.','managed_sessions':[53551,91025,36879],'managed_sessions_stopped':True,'temporary_successful_browser_tab_closed':True}}
(EVIDENCE/'launch-record.json').write_text(json.dumps(launch,indent=2),encoding='utf-8')

commands = json.loads((EVIDENCE/'commands.json').read_text(encoding='utf-8'))
results = {c['label']:c.get('counts',{}) for c in commands if c.get('counts')}
assert results['builder-m1-m2-tests']['pass']==64 and results['builder-m1-m2-tests']['fail']==0
assert results['unchanged-independent-m1-tests']['pass']==22 and results['unchanged-independent-m1-tests']['fail']==0
assert results['independent-m2-tests']['pass']==18 and results['independent-m2-tests']['fail']==0
baseline=(EVIDENCE/'m0-baseline-audit.txt').read_text(encoding='utf-8')
assert '"checksPassed": 7' in baseline and '"checksFailed": 0' in baseline
browser=json.loads((EVIDENCE/'browser-checks.json').read_text(encoding='utf-8'))
assert len(browser)==8 and all(c['passed'] for c in browser)
assert json.loads((EVIDENCE/'browser-console.json').read_text())==[]
causal=json.loads((EVIDENCE/'causal-comparison.json').read_text())
assert causal['result']=='PASS'
assert sha((EVIDENCE/'Independent_M2_Browser_Run.json').read_bytes())==causal['browser_run_sha256']
assert sha((EVIDENCE/'Independent_M2_Browser_Inspector.json').read_bytes())==causal['browser_trace_sha256']
results['baseline']={'pass':7,'fail':0}
results['browser_check_groups']={'pass':8,'fail':0}
(EVIDENCE/'results.json').write_text(json.dumps(results,indent=2),encoding='utf-8')

report=OUT/'M2_Independent_Test_Report.md'
text=report.read_text(encoding='utf-8')
sections=['Build/checkpoint tested','Environment','Launch result','Automated tests executed','Manual/browser checks executed','M2 path result','Information-boundary result','Idempotency/staleness result','Portability result','Inspector/causal-trace result','Defects by severity','Not tested / later scope','Subjective play observations','Milestone verdict']
assert re.findall(r'^## \d+\. (.+)$',text,re.M)==sections
assert '**READY FOR NEXT SCOPE**' in text and identity['sha256'] in text
proof=OUT/'M2_Independent_Browser_Complete.jpg'
shutil.copyfile(EVIDENCE/'browser-complete.jpg',proof)
assert sha(proof.read_bytes())==sha((EVIDENCE/'browser-complete.jpg').read_bytes())

items=[(report.name,report),(proof.name,proof),('M2_Independent_Interaction_Transcript.md',OUT/'M2_Independent_Interaction_Transcript.md'),('M2_Independent_Contract_Tests.test.mjs',OUT/'M2_Independent_Contract_Tests.test.mjs'),('M1_Independent_Contract_Tests.test.mjs',OUT/'M1_Independent_Contract_Tests.test.mjs')]
items += [('inputs/'+file.name,file) for file in sorted(HANDOFF.iterdir()) if file.is_file() and file.name in ['HANDOFF_PROVENANCE.txt','Encounter_M2_Checkpoint.identity.json','Encounter_M2_Checkpoint.zip','M2_Interaction_Transcript.md','README.md','Test_Results_and_Scope.md']]
items += [('evidence/'+file.name,file) for file in sorted(EVIDENCE.iterdir()) if file.is_file()]
items += [('review-tools/'+name,ROOT/'work'/name) for name in ['verify_m2_checkpoint.py','run_m2_checks.py','run_m2_independent.py','compare_m2_causal_evidence.mjs','m2_preview_server.py','package_m2_review.py']]
manifest=[{'path':name,'bytes':file.stat().st_size,'sha256':sha(file.read_bytes())} for name,file in items]
bundle=OUT/'M2_Independent_Test_Evidence.zip'
with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED) as z:
    for name,file in items:z.write(file,name)
    z.writestr('review-manifest.json',json.dumps({'checkpoint_sha256':identity['sha256'],'milestone_verdict':'READY FOR NEXT SCOPE','members':manifest},indent=2))
with zipfile.ZipFile(bundle) as z:
    assert z.testzip() is None and len(z.namelist())==len(manifest)+1
    for entry in manifest:
        b=z.read(entry['path']);assert len(b)==entry['bytes'] and sha(b)==entry['sha256']
print(json.dumps({'report':str(report),'evidence_bundle':str(bundle),'bundle_bytes':bundle.stat().st_size,'bundle_members':len(manifest)+1,'screenshot':str(proof),'results':results,'preservation':'PASS','artifact_qa':'PASS'},indent=2))
